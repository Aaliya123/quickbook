<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $company_id = $_POST['company_id'];
                $who_you_paid = $_POST['who_you_paid'];
                $date = $_POST['date'];
                $method = $_POST['method'];
                $sale_tax = $_POST['sale_tax'];
                $price = $_POST['price'];
                $ref = $_POST['ref'];
                $mess_to_state = $_POST['mess_to_state'];

                //check email existed or not

                        $query = "INSERT INTO `new_expense` (`expense_id`,`who_you_paid`, `date`, `method`, `sale_tax`, `price`, `ref`, `mess_to_state`,`company_id`)
                        VALUES (NULL, '$who_you_paid', '$date', '$method', '$sale_tax', '$price', '$ref', '$mess_to_state','$company_id')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
