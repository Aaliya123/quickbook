<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['auth_key']) && $_GET['auth_key'] == $auth_key) {
            $id = $_GET['user_id'];
            $query = "SELECT * FROM `customers` WHERE `company_id`=$id";
            $run = mysqli_query($conn, $query);
            if (mysqli_num_rows($run) > 0) {
                while ($row = mysqli_fetch_array($run)) {
                    $temp = array();
                    $temp['id'] = $row['id'];
                    $temp['name'] = $row['name'];
                    $temp['company_name'] = $row['company_name'];
                    $temp['phone'] = $row['phone'];
                    $temp['mobile'] = $row['mobile'];
                    $temp['fax'] = $row['fax'];
                    $temp['email'] = $row['email'];
                    $temp['address1'] = $row['address1'];
                    $temp['address2'] = $row['address2'];
                    $temp['address3'] = $row['address3'];
                    $temp['city'] = $row['city'];
                    $temp['state'] = $row['state'];
                    $temp['zip'] = $row['zip'];
                    $temp['country'] = $row['country'];
                    $temp['code'] = 1;
                    array_push($output, $temp);
                }
                echo json_encode($output, JSON_UNESCAPED_SLASHES);
            } else {
                $temp['code'] = 0;
                array_push($output, $temp);
                echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        } else {
            $temp['code'] = "Access forbidden";
            array_push($output, $temp);
            echo json_encode($output, JSON_UNESCAPED_SLASHES);
        }
    }
} else {
    $temp['code'] = "connection error";
    array_push($output, $temp);
    echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
