<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $company_id = $_POST['company_id'];
                $cutomer = $_POST['cutomer'];
                $method = $_POST['method'];
                $date = $_POST['date'];
                $ref_no = $_POST['ref_no'];
                $amount = $_POST['amount'];
                $unapp_amount = $_POST['unapp_amount'];
                $mess_to_cus = $_POST['mess_to_cus'];

                //check email existed or not

                        $query = "INSERT INTO `invoice_payment` (`invoice_payment_id`, `cutomer`, `method`, `date`, `ref_no`, `amount`, `unapp_amount`, `mess_to_cus`,`company_id`)
                        VALUES (NULL, '$cutomer', '$method', '$date', '$ref_no', '$amount', '$unapp_amount', '$mess_to_cus','$company_id')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
