<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                
                $id = $_GET['id'];
                $name = $_POST['name'];
                $company_name = $_POST['company_name'];
                $phone = $_POST['phone'];
                $mobile = $_POST['mobile'];
                $fax = $_POST['fax'];
                $email = $_POST['email'];
                $address1 = $_POST['address1'];
                $address2 = $_POST['address2'];
                $address3 = $_POST['address3'];
                $city = $_POST['city'];
                $state = $_POST['state'];
                $zip = $_POST['zip'];
                $country = $_POST['country'];
                $user_id = $_GET['user_id'];

                //check email existed or not

                    
                    
                        $query = "UPDATE customers SET name='$name',company_name='$company_name',phone='$phone',mobile='$mobile',fax='$fax',email='$email',address1='$address1',address2='$address2',address3='$address3',city='$city',state='$state',zip='$zip',country='$country' WHERE `id`=$id AND company_id='$user_id'";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
