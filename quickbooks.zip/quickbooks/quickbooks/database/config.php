<?php
    //$conn = mysqli_connect("localhost", "u599120626_bce_system", "=zUQwx#Nu0", "u599120626_bce_system");
    $conn = mysqli_connect("localhost", "root", "", "quickbooks");
    //$conn = mysqli_connect("localhost", "samitkts_chat_junkies", "samitkts_chat_junkies", "samitkts_chat_junkies");
    $auth_key="123456789abvfggvsgretsig4894318";
?>