<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
            $email = $_POST['email'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $query = "SELECT * FROM `users` 
            WHERE email='$email' AND password='$password'";
            $run = mysqli_query($conn, $query);
            if (mysqli_num_rows($run) > 0) {
                $row = mysqli_fetch_array($run);
                $temp['id'] = $row['id'];
                $temp['email'] = $row['email'];
                $temp['username'] = $row['username'];
                $temp['password'] = $row['password'];
                $temp['code'] = 1;
                array_push($output, $temp);
                echo json_encode($output, JSON_UNESCAPED_SLASHES);
            } else {
                $temp['code'] = 0;
                array_push($output, $temp);
                echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        } else {
            $temp['code'] = "Access forbidden";
            array_push($output, $temp);
            echo json_encode($output, JSON_UNESCAPED_SLASHES);
        }
    }
} else {
    $temp['code'] = "connection error";
    array_push($output, $temp);
    echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
