<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $company_id = $_POST['company_id'];
                $name = $_POST['name'];
                $company_name = $_POST['company_name'];
                $phone = $_POST['phone'];
                $mobile = $_POST['mobile'];
                $fax = $_POST['fax'];
                $email = $_POST['email'];
                $address1 = $_POST['address1'];
                $address2 = $_POST['address2'];
                $address3 = $_POST['address3'];
                $city = $_POST['city'];
                $state = $_POST['state'];
                $zip = $_POST['zip'];
                $country = $_POST['country'];

                //check email existed or not

                    $query = "SELECT * FROM `customers` 
                    WHERE email='$email'";
                    $run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($run) > 0) {
                        echo "already registered";                
                    } else {
                        $query = "INSERT INTO `customers` (`id`, `name`, `company_name`, `phone`, `mobile`, `fax`, `email`, `address1`, `address2`, `address3`, `city`, `state`, `zip`, `country`,`company_id`)
                        VALUES (NULL, '$name', '$company_name', '$phone', '$mobile', '$fax', '$email', '$address1', '$address2', '$address3', '$city', '$state', '$zip', '$country','$company_id')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            }
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
