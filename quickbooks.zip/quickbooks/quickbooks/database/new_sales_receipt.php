<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $company_id = $_POST['company_id'];
                $cus_name = $_POST['cus_name'];
                $method = $_POST['method'];
                $date = $_POST['date'];
                $sr_no = $_POST['sr_no'];
                $sales_tax = $_POST['sales_tax'];
                $price = $_POST['price'];
                $mess_to_cus = $_POST['mess_to_cus'];
                $mess_to_state = $_POST['mess_to_state'];

                //check email existed or not

                        $query = "INSERT INTO `sales_receipt` (`sale_receipt_id`, `cus_name`, `method`, `date`, `sr_no`,`sales_tax`, `price`, `mess_to_cus`, `mess_to_state`,`company_id`)
                        VALUES (NULL, '$cus_name', '$method', '$date', '$sr_no', '$sales_tax', '$price', '$mess_to_cus', '$mess_to_state','$company_id')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
