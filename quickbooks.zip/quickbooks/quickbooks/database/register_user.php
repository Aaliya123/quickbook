<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $email = $_POST['email'];
                $username = $_POST['username'];
                $password = $_POST['password'];

                //check email existed or not

                    $query = "SELECT * FROM `users` 
                    WHERE email='$email'";
                    $run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($run) > 0) {
                        echo "already registered";                
                    } else {
                        $query = "INSERT INTO `users` (`id`, `email`, `username`, `password`)
                        VALUES (NULL, '$email', '$username', '$password')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            }
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
