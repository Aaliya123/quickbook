<?php
$output = array();
$temp = array();
$temp['id'] = "1";
$temp['user_email'] = "1";
$temp['user_mobile'] = "1";
$temp['user_profile'] = "1";
$temp['code'] = 1;
$temp['active'] = "1";

array_push($output, $temp);
echo json_encode($output, JSON_UNESCAPED_SLASHES);

?>