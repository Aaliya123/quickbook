<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['auth_key']) && $_GET['auth_key'] == $auth_key) {
            $company_id = $_GET['company_id'];
            $query = "SELECT * FROM invoice_payment WHERE company_id=$company_id";
            $run = mysqli_query($conn, $query);
            if (mysqli_num_rows($run) > 0) {
                while ($row = mysqli_fetch_array($run)) {
                    $temp = array();
                    $temp['invoice_payment_id'] = $row['invoice_payment_id'];
                    $temp['cutomer'] = $row['cutomer'];
                    $temp['method'] = $row['method'];
                    $temp['date'] = $row['date'];
                    $temp['ref_no'] = $row['ref_no'];
                    $temp['amount'] = $row['amount'];
                    $temp['unapp_amount'] = $row['unapp_amount'];
                    $temp['mess_to_cus'] = $row['mess_to_cus'];
                    $temp['code'] = 1;
                    array_push($output, $temp);
                }
                echo json_encode($output, JSON_UNESCAPED_SLASHES);
            } else {
                $temp['code'] = 0;
                array_push($output, $temp);
                echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        } else {
            $temp['code'] = "Access forbidden";
            array_push($output, $temp);
            echo json_encode($output, JSON_UNESCAPED_SLASHES);
        }
    }
} else {
    $temp['code'] = "connection error";
    array_push($output, $temp);
    echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
