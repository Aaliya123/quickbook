<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $invoice_id = $_GET['invoice_id'];
                $user_id = $_POST['user_id'];
                $cus_name = $_POST['cus_name'];
                $invoice_no = $_POST['invoice_no'];
                $date = $_POST['date'];
                $due_on = $_POST['due_on'];
                $discount = $_POST['discount'];
                $shipping_fee = $_POST['shipping_fee'];
                $sales_tax = $_POST['sales_tax'];
                $price = $_POST['price'];
                $mess_to_cus = $_POST['mess_to_cus'];
                $mess_to_state = $_POST['mess_to_state'];

                //check email existed or not

                        $query = "UPDATE invoices SET cus_name='$cus_name',invoice_no='$invoice_no',
                        date='$date',due_on='$due_on',discount='$discount',shipping_fee='$shipping_fee',sales_tax='$sales_tax',
                        price='$price',mess_to_cus='$mess_to_cus',mess_to_state='$mess_to_state' WHERE `invoice_id`=$invoice_id AND `user_id` =$user_id";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
