<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $company_id = $_POST['company_id'];
                $name = $_POST['name'];
                $unit_price = $_POST['unit_price'];
                $des = $_POST['des'];

                //check email existed or not

                        $query = "INSERT INTO `new_product_service` (`new_product_service_id`, `name`, `unit_price`, `des`,`company_id`)
                        VALUES (NULL, '$name', '$unit_price', '$des','$company_id')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
