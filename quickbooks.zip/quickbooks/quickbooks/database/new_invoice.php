<?php
require 'config.php';
$output = array();
if ($conn) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        //if (!empty($_FILES)) {
            if (isset($_POST['auth_key']) && $_POST['auth_key'] == $auth_key) {
                $company_id = $_POST['company_id'];
                $cus_name = $_POST['cus_name'];
                $invoice_no = $_POST['invoice_no'];
                $date = $_POST['date'];
                $due_on = $_POST['due_on'];
                $discount = $_POST['discount'];
                $shipping_fee = $_POST['shipping_fee'];
                $sales_tax = $_POST['sales_tax'];
                $price = $_POST['price'];
                $mess_to_cus = $_POST['mess_to_cus'];
                $mess_to_state = $_POST['mess_to_state'];

                //check email existed or not

                        $query = "INSERT INTO `invoices` (`invoice_id`, `cus_name`, `invoice_no`, `date`, `due_on`, `discount`, `shipping_fee`, `sales_tax`, `price`, `mess_to_cus`, `mess_to_state`,`user_id`)
                        VALUES (NULL, '$cus_name', '$invoice_no', '$date', '$due_on', '$discount', '$shipping_fee', '$sales_tax', '$price', '$mess_to_cus', '$mess_to_state','$company_id')";
                            if (mysqli_query($conn, $query)) {
                                echo "registered";
                            } else {
                                echo "not registered";
                            }
            
                
            }
             else {
                // $temp = array();
                // $temp['code'] = "Access forbidden";
                echo "Access forbidden";
                // array_push($output, $temp);
                // echo json_encode($output, JSON_UNESCAPED_SLASHES);
            }
        //}
    }
} else {
    // $temp = array();
    // $temp['code'] = "Connection Error";
    echo "Connection Error";
    // array_push($output, $temp);
    // echo json_encode($output, JSON_UNESCAPED_SLASHES);
}
