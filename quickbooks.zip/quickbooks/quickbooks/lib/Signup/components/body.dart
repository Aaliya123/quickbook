import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:quickbooks/components/rounded_button.dart';
import 'package:quickbooks/components/rounded_input_field.dart';
import 'package:quickbooks/components/rounded_password_field.dart';
import 'package:quickbooks/constants.dart';
import 'package:quickbooks/Signup/components/background.dart';
import 'package:quickbooks/components/text_field_container.dart';
import 'package:quickbooks/main.dart';
import 'package:quickbooks/user/dashboard.dart';
import 'package:quickbooks/constants.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Body extends StatefulWidget {
  @override
  _Body createState() => _Body();
}

class _Body extends State<Body> {
  GlobalKey<FormState> formkey = GlobalKey<FormState>();
  bool _showPassword = false;

  final _NameController = TextEditingController();
  final _EmailController = TextEditingController();
  final _PasswordController = TextEditingController();

  void validate() {
    if (formkey.currentState.validate()) {
      var _user_email = _EmailController.text;
      var _user_password = _PasswordController.text;
      var _user_name = _NameController.text;

      Register_login(_user_email, _user_password, _user_name);
    } else {
      Fluttertoast.showToast(
          msg: "Please fill the fields",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  Future Register_login(
      String _user_email, String _user_password, String _user_name) async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    final uri = Uri.parse(base_url + "register_user.php");
    var request = http.MultipartRequest('POST', uri);
    request.fields['email'] = _user_email;
    request.fields['password'] = _user_password;
    request.fields['username'] = _user_name;
    request.fields['auth_key'] = auth_key;
    var response = await request.send().then((result) async {
      http.Response.fromStream(result).then((response) {
        if (response.body == "registered") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "registered successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
          //
          Login(_user_email, _user_password, _user_name);
        } else if (response.body == "already registered") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "already registered",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
          Login(_user_email, _user_password, _user_name);
        } else if (response.body == "Access forbidden") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Access forbidden",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Connection Error") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Connection Error",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else {
          dialog.hide();
          Fluttertoast.showToast(
              msg: response.body,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      });
    });
  }

  Future Login(
      String _user_email, String _user_password, String _user_name) async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    var url = base_url + "login.php";
    var response = await http.post(url, body: {
      "email": _user_email,
      "password": _user_password,
      "username": _user_name,
      "auth_key": auth_key
    });
    var data = json.decode(response.body);
    var code = data[0]['code'];
    print(code);
    if (code == 1) {
      await dialog.hide();
      Fluttertoast.showToast(
          msg: "Login Successfully",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);

      addStringToSF() async {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        prefs.setString('id', data[0]['id']);
        prefs.setString('email', data[0]['email']);
        prefs.setString('username', data[0]['username']);
        prefs.setString('password', data[0]['password']);
        //prefs.setString('is_logged_in', 'yes');
      }

      addStringToSF();
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) {
            return UserDashboard();
          },
        ),
      );
      // var route = new MaterialPageRoute(
      //     builder: (BuildContext context) => new Topics(from:"register"));
      // Navigator.of(context).push(route);
    } else if (code == 0) {
      dialog.hide();
      Fluttertoast.showToast(
          msg: "Invalid password",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    } else {
      dialog.hide();
      Fluttertoast.showToast(
          msg: response.body,
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Background(
      child: SingleChildScrollView(
        child: Form(
          autovalidate: true,
          key: formkey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                "LOG IN",
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: size.height * 0.03),
              // SvgPicture.asset(
              //   "assets/icons/login.svg",
              //   height: size.height * 0.30,
              // ),
              TextFieldContainer(
                child: TextFormField(
                  controller: _NameController,
                  // onChanged: onChanged,
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    icon: Icon(
                      Icons.person,
                      color: kPrimaryColor,
                    ),
                    hintText: "Business name",
                    border: InputBorder.none,
                  ),
                  validator: MultiValidator([
                    RequiredValidator(errorText: "Required"),
                    LengthRangeValidator(
                        min: 3,
                        max: 15,
                        errorText: "Should Be At Least more than 3 characters")
                  ]),
                ),
              ),
              TextFieldContainer(
                child: TextFormField(
                  controller: _EmailController,
                  // onChanged: onChanged,
                  cursorColor: kPrimaryColor,
                  decoration: InputDecoration(
                    icon: Icon(
                      Icons.person,
                      color: kPrimaryColor,
                    ),
                    hintText: "Email",
                    border: InputBorder.none,
                  ),
                  validator: MultiValidator([
                    RequiredValidator(errorText: "Required"),
                    EmailValidator(errorText: "Not A Valid Email")
                  ]),
                ),
              ),
              TextFieldContainer(
                child: TextFormField(
                  controller: _PasswordController,
                  // onChanged: onChanged,
                  cursorColor: kPrimaryColor,
                  obscureText: !this._showPassword,
                  decoration: InputDecoration(
                    hintText: "Password",
                    icon: Icon(
                      Icons.lock,
                      color: kPrimaryColor,
                    ),
                    suffixIcon: IconButton(
                      icon: Icon(
                        Icons.remove_red_eye,
                        color: kPrimaryColor,
                      ),
                      onPressed: () {
                        setState(
                            () => this._showPassword = !this._showPassword);
                      },
                    ),
                    // suffixIcon: Icon(
                    //   Icons.visibility,
                    //   color: kPrimaryColor,
                    // ),
                    border: InputBorder.none,
                  ),
                  validator: (value) {
                    if (value.isEmpty) {
                      return "required";
                    } else if (value.length < 4) {
                      return "Password Should Be At Least 4 Characters";
                    } else {
                      return null;
                    }
                  },
                ),
              ),

              RoundedButton(
                text: "LOG IN OR Sign up",
                press: () {
                  setState(() {
                    validate();
                  });
                },
              ),
              // SizedBox(height: size.height * 0.03),
              // AlreadyHaveAnAccountCheck(
              //   login: false,
              //   press: () {
              //     Navigator.push(
              //       context,
              //       MaterialPageRoute(
              //         builder: (context) {
              //           return LoginScreen();
              //         },
              //       ),
              //     );
              //   },
              // ),
              // OrDivider(),
              // Row(
              //   mainAxisAlignment: MainAxisAlignment.center,
              //   children: <Widget>[
              //     SocalIcon(
              //       iconSrc: "assets/icons/facebook.svg",
              //       press: () {},
              //     ),
              //     SocalIcon(
              //       iconSrc: "assets/icons/twitter.svg",
              //       press: () {},
              //     ),
              //     SocalIcon(
              //       iconSrc: "assets/icons/google-plus.svg",
              //       press: () {},
              //     ),
              //   ],
              // ),
            ],
          ),
        ),
      ),
    );
  }
}
