import 'package:flutter/material.dart';

class Palette {
  static const Color appbar = Color(0xFFFFFFFF);
  static const Color main = Color(0xFF53B700);
  static const Color primaryColor = Color(0xFF53B700);
}