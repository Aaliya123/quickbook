import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:quickbooks/constants.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:quickbooks/user/user_menu/customers.dart';
import 'package:shared_preferences/shared_preferences.dart';

class EditCustomer extends StatefulWidget {
  String id;
  String name;
  String company_name;
  String phone;
  String mobile;
  String fax;
  String email;
  String address1;
  final String address2;
  final String address3;
  final String city;
  final String state;
  final String zip;
  final String country;

  EditCustomer({
    Key key,
    this.id,
    this.name,
    this.company_name,
    this.phone,
    this.mobile,
    this.fax,
    this.email,
    this.address1,
    this.address2,
    this.address3,
    this.city,
    this.state,
    this.zip,
    this.country,
  }) : super(key: key);
  @override
  _EditCustomer createState() => _EditCustomer(name);
}

class _EditCustomer extends State<EditCustomer> {
  String name;
  _EditCustomer(this.name);
  final _nameController = TextEditingController();
  final _companyNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _mobileController = TextEditingController();
  final _faxController = TextEditingController();
  final _emailController = TextEditingController();
  final _address1Controller = TextEditingController();
  final _address2Controller = TextEditingController();
  final _address3Controller = TextEditingController();
  final _cityController = TextEditingController();
  final _stateController = TextEditingController();
  final _zipController = TextEditingController();
  final _countryController = TextEditingController();

  void fillfields() {
    _nameController.text = '${widget.name}';
    _companyNameController.text = '${widget.company_name}';
    _mobileController.text = '${widget.mobile}';
    _phoneController.text = '${widget.phone}';
    _emailController.text = '${widget.email}';
    _faxController.text = '${widget.fax}';
    _address1Controller.text = '${widget.address1}';
    _address2Controller.text = '${widget.address2}';
    _address3Controller.text = '${widget.address3}';
    _stateController.text = '${widget.state}';
    _zipController.text = '${widget.zip}';
    _countryController.text = '${widget.country}';
    _cityController.text = '${widget.city}';
  }


String user_id;
  @override
  Future<void> initState() {
    super.initState();
    getStringValuesSF();
  }

  getStringValuesSF() async {
    fillfields();
    SharedPreferences prefs = await SharedPreferences.getInstance();
    user_id = prefs.getString('id');
    setState(() {});
  }
  Future edit_Customer() async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    final uri = Uri.parse(base_url + "editcustomers.php?id='${widget.id}'&user_id=$user_id");
    var request = http.MultipartRequest('POST', uri);
    request.fields['name'] = _nameController.text;
    request.fields['company_name'] = _companyNameController.text;
    request.fields['phone'] = _phoneController.text;
    request.fields['mobile'] = _mobileController.text;
    request.fields['fax'] = _faxController.text;
    request.fields['email'] = _emailController.text;
    request.fields['address1'] = _address1Controller.text;
    request.fields['address2'] = _address2Controller.text;
    request.fields['address3'] = _address3Controller.text;
    request.fields['city'] = _cityController.text;
    request.fields['state'] = _stateController.text;
    request.fields['zip'] = _zipController.text;
    request.fields['country'] = _countryController.text;
    request.fields['auth_key'] = auth_key;
    var response = await request.send().then((result) async {
      http.Response.fromStream(result).then((response) {
        if (response.body == "registered") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Customer edited successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);

          var route = new MaterialPageRoute(
              builder: (BuildContext context) => new Customer());
          Navigator.of(context).push(route);
          //
        } else if (response.body == "not registered") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Customer is not updated successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Access forbidden") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Access forbidden",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Connection Error") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Connection Error",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else {
          dialog.hide();
          Fluttertoast.showToast(
              msg: response.body,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      });
    });
  }

 
  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(0xFFFFFFFF).withOpacity(0.9),
      appBar: AppBar(
        backgroundColor: Palette.appbar,
        elevation: 0.0,
        title: Text(
          '${widget.name}',
          style: TextStyle(color: Colors.black, fontFamily: 'Montserrat'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Palette.main),
          iconSize: 28.0,
          onPressed: () {
            Navigator.of(context).pop();
            setState(() {});
          },
        ),
        actions: <Widget>[
          // IconButton(
          //   icon: const Icon(Icons.no_meals_rounded, color: Palette.main),
          //   iconSize: 28.0,
          //   onPressed: () {
          //     setState(() {});
          //   },
          // ),
          IconButton(
            icon: const Icon(Icons.save, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {
                edit_Customer();
              });
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(5),
          child: Container(
            child: Column(
              children: [
                SizedBox(height: 10),
                Container(
                  child: Container(
                    margin: const EdgeInsets.only(left: 20.0),
                    alignment: FractionalOffset.topLeft,
                    child: Text(
                      "Personal info",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: const Color(0xFF000000),
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                ),
                Card(
                  elevation: 2,
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _nameController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Name',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _companyNameController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Company name',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                Container(
                  child: Container(
                    margin: const EdgeInsets.only(left: 20.0),
                    alignment: FractionalOffset.topLeft,
                    child: Text(
                      "Contact details",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: const Color(0xFF000000),
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                ),
                Card(
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _phoneController,
                          autofocus: true,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                            LengthRangeValidator(
                                min: 11,
                                max: 11,
                                errorText: "Should Be 11 digits")
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Phone (000) 000-000',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _mobileController,
                          autofocus: true,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                            LengthRangeValidator(
                                min: 11,
                                max: 11,
                                errorText: "Should Be 11 digits")
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Mobile (000) 000-000',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _faxController,
                          autofocus: true,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                            LengthRangeValidator(
                                min: 11,
                                max: 11,
                                errorText: "Should Be 11 digits")
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Fax (000) 000-000',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _emailController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                            EmailValidator(errorText: 'Not a valid email')
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Email assad@gmail.com',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30),
                Container(
                  child: Container(
                    margin: const EdgeInsets.only(left: 20.0),
                    alignment: FractionalOffset.topLeft,
                    child: Text(
                      "Billing address",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                          color: const Color(0xFF000000),
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Montserrat'),
                    ),
                  ),
                ),
                Card(
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _address1Controller,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Address 1',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _address2Controller,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Address 2',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _address3Controller,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Address 3',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _cityController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator(
                              [RequiredValidator(errorText: "Required")]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'City',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _stateController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'State',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _zipController,
                          autofocus: true,
                          keyboardType: TextInputType.number,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'ZIP',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _countryController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: MultiValidator([
                            RequiredValidator(errorText: "Required"),
                          ]),
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Country',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
