import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:quickbooks/config/palette.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:quickbooks/user/user_menu/invoices.dart';

import '../../constants.dart';

class EditInvoice extends StatefulWidget {
  String invoice_id,
      cus_name,
      invoice_no,
      date,
      due_on,
      discount,
      shipping_fee,
      sales_tax,
      price,
      mess_to_cus,
      mess_to_state;

  EditInvoice(
      {Key key,
      this.invoice_id,
      this.cus_name,
      this.invoice_no,
      this.date,
      this.due_on,
      this.discount,
      this.shipping_fee,
      this.price,
      this.sales_tax,
      this.mess_to_cus,
      this.mess_to_state})
      : super(key: key);
  @override
  _EditInvoice createState() => _EditInvoice();
}

class _EditInvoice extends State<EditInvoice> {
  List<_selectedCustomer> users = [];
  String _selectedCustomervalue = 'name';
  //List<String> _selectedCustomer = [' Mudassir'];

  Future<List<_selectedCustomer>> _GetUsers() async {
    var Users =
        await http.get(base_url + "GetCustomerName.php?auth_key=$auth_key");
    var JsonData = json.decode(Users.body);
    for (var u in JsonData) {
      _selectedCustomer item = _selectedCustomer(u["id"], u["name"], u["code"]);
      users.add(item);
    }
    // Fluttertoast.showToast(
    //       msg: '$users',
    //       toastLength: Toast.LENGTH_SHORT,
    //       gravity: ToastGravity.CENTER,
    //       timeInSecForIosWeb: 1,
    //       backgroundColor: Colors.red,
    //       textColor: Colors.white,
    //       fontSize: 16.0
    //   );
    return users;
  }

  String _selecteddate = ' 19/03/2021';
  List<String> _dates = [
    ' 19/03/2021',
    ' 20/03/2021',
    ' 21/03/2021',
    ' 22/03/2021',
    ' 23/03/2021',
    ' 27/03/2021',
    ' 28/03/2021',
    ' 29/03/2021',
    ' 30/03/2021',
    ' 31/03/2021',
    ' 01/04/2021',
    ' 02/04/2021',
    ' 02/04/2021',
  ];
  String _selectedduedate = ' 19/03/2021';
  List<String> _duedates = [
    ' 19/03/2021',
    ' 20/03/2021',
    ' 21/03/2021',
    ' 22/03/2021',
    ' 23/03/2021',
    ' 27/03/2021',
    ' 28/03/2021',
    ' 29/03/2021',
    ' 30/03/2021',
    ' 31/03/2021',
    ' 01/04/2021',
    ' 02/04/2021',
    ' 02/04/2021',
  ];
  String _selectedsalestax = ' Excluded from amounts';
  List<String> _salestaxdates = [
    ' Excluded from amounts',
    ' Included in amounts',
    ' Not applicable'
  ];

  final _InvoiceNoController = TextEditingController();
  final _DateController = TextEditingController();
  final _DueOnController = TextEditingController();
  final _DiscountController = TextEditingController();
  final _ShippingFeeController = TextEditingController();
  final _PriceController = TextEditingController();
  final _MessageToCustomerController = TextEditingController();
  final _MessageOnStatementController = TextEditingController();

  fillfields() {
    _InvoiceNoController.text = '${widget.invoice_no}';
    _DateController.text = '${widget.date}';
    _DueOnController.text = '${widget.due_on}';
    _DiscountController.text = '${widget.discount}';
    _ShippingFeeController.text = '${widget.shipping_fee}';
    _PriceController.text = '${widget.price}';
    _MessageToCustomerController.text = '${widget.mess_to_cus}';
    _MessageOnStatementController.text = '${widget.mess_to_state}';
    _selectedsalestax = '${widget.sales_tax}';
    // _selectedsalestax = '${widget.sales_tax}';
  }

  Future Add_newnvoice() async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    final uri = Uri.parse(
        base_url + "edit_invoices.php?invoice_id='${widget.invoice_id}'");
    var request = http.MultipartRequest('POST', uri);
    request.fields['cus_name'] = _selectedCustomervalue;
    request.fields['invoice_no'] = _InvoiceNoController.text;
    request.fields['date'] = _DateController.text;
    request.fields['due_on'] = _DueOnController.text;
    request.fields['discount'] = _DiscountController.text;
    request.fields['shipping_fee'] = _ShippingFeeController.text;
    request.fields['sales_tax'] = _selectedsalestax;
    request.fields['price'] = _PriceController.text;
    request.fields['mess_to_cus'] = _MessageToCustomerController.text;
    request.fields['mess_to_state'] = _MessageOnStatementController.text;
    request.fields['auth_key'] = auth_key;
    var response = await request.send().then((result) async {
      http.Response.fromStream(result).then((response) {
        if (response.body == "registered") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Invoice edit successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);

          var route = new MaterialPageRoute(
              builder: (BuildContext context) => new Invoices());
          Navigator.of(context).push(route);
          //
        } else if (response.body == "Access forbidden") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Access forbidden",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Connection Error") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Connection Error",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else {
          dialog.hide();
          Fluttertoast.showToast(
              msg: response.body,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      });
    });
  }

  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        _DateController.text =
            "${currentDate.day}-${currentDate.month}-${currentDate.year}";
      });
  }

  Future<void> _selectDateDue(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        _DueOnController.text =
            "${currentDate.day}/${currentDate.month}/${currentDate.year}";
      });
  }

  Future<void> initState() {
    super.initState();
    _GetUsers();
    fillfields();
  }

  @override
  Widget build(BuildContext context) {
    //List<_selectedCustomer> users = [];
    var countryDropDown = Container(
      decoration: new BoxDecoration(
        color: const Color(0xFFf1f1f1),
        border: Border(
          right: BorderSide(width: 0.5, color: const Color(0xFFf1f1f1)),
        ),
      ),
      // height: 45.0,

      // margin: const EdgeInsets.all(3.0),

      child: DropdownButtonHideUnderline(
        child: ButtonTheme(
          alignedDropdown: false,
          child: DropdownButton(
            // iconSize: 0.0,

            value: _selectedCustomervalue,
            items: users.map((_selectedCustomer user) {
              return new DropdownMenuItem<_selectedCustomer>(
                  value: user,
                  child: new Text(
                    user.name,
                    style: TextStyle(fontSize: 12.0),
                  ));
            }).toList(),
            onChanged: (value) {
              setState(() {
                _GetUsers();
                _selectedCustomervalue = value;
              });
            },
            // ignore: deprecated_member_use
            style: Theme.of(context).textTheme.title,
          ),
        ),
      ),
    );
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(0xFFf1f1f1).withOpacity(0.9),
      appBar: AppBar(
        backgroundColor: Palette.appbar,
        elevation: 0.0,
        title: Text(
          'edit ${widget.cus_name}',
          style: TextStyle(color: Colors.black, fontFamily: 'Montserrat'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Palette.main),
          iconSize: 28.0,
          onPressed: () {
            Navigator.of(context).pop();
            setState(() {});
          },
        ),
        actions: <Widget>[
          // IconButton(
          //   icon: const Icon(Icons.no_meals_rounded, color: Palette.main),
          //   iconSize: 28.0,
          //   onPressed: () {
          //     setState(() {});
          //   },
          // ),
          IconButton(
            icon: const Icon(Icons.save, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {
                Add_newnvoice();
                Fluttertoast.showToast(
                    msg: 'invoice edit successfully',
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.CENTER,
                    timeInSecForIosWeb: 1,
                    backgroundColor: Colors.green,
                    textColor: Colors.white,
                    fontSize: 16.0);
              });
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(5),
          child: Container(
            child: Column(
              children: [
                // SizedBox(height: 10),
                // Container(
                //   child: Container(
                //     margin: const EdgeInsets.only(left: 20.0),
                //     alignment: FractionalOffset.topLeft,
                //     child: Text(
                //       "Personal info",
                //       textAlign: TextAlign.center,
                //       style: TextStyle(
                //           color: const Color(0xFF000000),
                //           fontSize: 16,
                //           fontWeight: FontWeight.w600,
                //           fontFamily: 'Montserrat'),
                //     ),
                //   ),
                // ),
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(0),
                  ),
                  elevation: 2,
                  child: Column(
                    children: [
                      // Padding(
                      //   padding: EdgeInsets.all(10),
                      //   child: TextFormField(
                      //     autofocus: true,
                      //     keyboardType: TextInputType.name,
                      //     textInputAction: TextInputAction.next,
                      //     validator: (name) {
                      //       Pattern pattern =
                      //           r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                      //       RegExp regex = new RegExp(pattern);
                      //       if (!regex.hasMatch(name))
                      //         return 'Invalid name';
                      //       else
                      //         return null;
                      //     },
                      //     style: TextStyle(
                      //         fontSize: 16.0,
                      //         color: Colors.black,
                      //         fontWeight: FontWeight.w600,
                      //         fontFamily: 'Montserrat'),
                      //     decoration: InputDecoration(
                      //       // filled: true,
                      //       // fillColor: const Color(0xFFf1f1f1),
                      //       hintText: 'Customer',
                      //       contentPadding: const EdgeInsets.only(
                      //           left: 14.0, bottom: 8.0, top: 8.0),
                      //       focusedBorder: OutlineInputBorder(
                      //           //borderSide:
                      //           // BorderSide(color: const Color(0xFFf1f1f1)),
                      //           // borderRadius: BorderRadius.circular(5),
                      //           ),
                      //       // enabledBorder: UnderlineInputBorder(
                      //       //   borderSide:
                      //       //       BorderSide(color: const Color(0xFFf1f1f1)),
                      //       //   borderRadius: BorderRadius.circular(5),
                      //       // ),
                      //     ),
                      //   ),
                      // ),
                      //
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: Container(
                          decoration: new BoxDecoration(
                            color: const Color(0xFFf1f1f1),
                            border: Border(
                              right: BorderSide(
                                  width: 1, color: const Color(0xFFf1f1f1)),
                            ),
                          ),
                          height: 45.0,
                          margin: const EdgeInsets.all(3.0),
                          width: 300.0,
                          child: DropdownButtonHideUnderline(
                            child: ButtonTheme(
                              alignedDropdown: true,
                              child: DropdownButton(
                                hint: Text('select customer'),
                                // iconSize: 0.0,
                                value: _selectedCustomervalue,
                                items: users.map((_selectedCustomer user) {
                                  return new DropdownMenuItem<
                                          _selectedCustomer>(
                                      value: user,
                                      child: new Text(
                                        user.name,
                                        style: TextStyle(fontSize: 12.0),
                                      ));
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _GetUsers();
                                    _selectedCustomervalue = value;
                                  });
                                },
                                // ignore: deprecated_member_use
                                style: Theme.of(context).textTheme.title,
                              ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: TextFormField(
                          controller: _InvoiceNoController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: (name) {
                            Pattern pattern =
                                r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(name))
                              return 'Invalid name';
                            else
                              return null;
                          },
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Invoice No',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                // SizedBox(height: 30),
                // Container(
                //   child: Container(
                //     margin: const EdgeInsets.only(left: 20.0),
                //     alignment: FractionalOffset.topLeft,
                //     child: Text(
                //       "Contact details",
                //       textAlign: TextAlign.center,
                //       style: TextStyle(
                //           color: const Color(0xFF000000),
                //           fontSize: 16,
                //           fontWeight: FontWeight.w600,
                //           fontFamily: 'Montserrat'),
                //     ),
                //   ),
                // ),
                Card(
                  child: Column(
                    children: [
                      // SizedBox(height: 10),
                      // Container(
                      //   child: Container(
                      //     margin: const EdgeInsets.only(left: 20.0),
                      //     alignment: FractionalOffset.topLeft,
                      //     child: Text(
                      //       "Terms",
                      //       textAlign: TextAlign.center,
                      //       style: TextStyle(
                      //           color: const Color(0xFF000000),
                      //           fontSize: 16,
                      //           fontWeight: FontWeight.w600,
                      //           fontFamily: 'Montserrat'),
                      //     ),
                      //   ),
                      // ),
                      // Padding(
                      //   padding: EdgeInsets.all(5),
                      //   child: Container(
                      //     decoration: new BoxDecoration(
                      //       color: const Color(0xFFf1f1f1),
                      //       border: Border(
                      //         right: BorderSide(
                      //             width: 1, color: const Color(0xFFf1f1f1)),
                      //       ),
                      //     ),
                      //     height: 45.0,
                      //     margin: const EdgeInsets.all(3.0),
                      //     width: 300.0,
                      //     child: DropdownButtonHideUnderline(
                      //       child: ButtonTheme(
                      //         alignedDropdown: true,
                      //         child: DropdownButton(
                      //           // iconSize: 0.0,
                      //           value: _selectedCountryCode,
                      //           items: _countryCodes.map((String value) {
                      //             return new DropdownMenuItem<String>(
                      //                 value: value,
                      //                 child: new Text(
                      //                   value,
                      //                   style: TextStyle(fontSize: 12.0),
                      //                 ));
                      //           }).toList(),
                      //           onChanged: (value) {
                      //             setState(() {
                      //               _selectedCountryCode = value;
                      //             });
                      //           },
                      //           // ignore: deprecated_member_use
                      //           style: Theme.of(context).textTheme.title,
                      //         ),
                      //       ),
                      //     ),
                      //   ),
                      // ),
                      SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 20.0),
                                    alignment: FractionalOffset.topLeft,
                                    child: Text(
                                      "Date",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: const Color(0xFF000000),
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: GestureDetector(
                                    onTap: () {
                                      _selectDate(context);
                                      // showDatePicker(
                                      //   context: context,
                                      //   initialDate: DateTime.now(),
                                      //   firstDate: DateTime(2000),
                                      //   lastDate: DateTime(3000),
                                      // ).then((value) {
                                      //   setState(() {
                                      //     // _dateTime=value;
                                      //   });
                                      // });
                                    },
                                    child: AbsorbPointer(
                                      child: TextFormField(
                                        controller: _DateController,
                                        autofocus: true,
                                        keyboardType: TextInputType.name,
                                        textInputAction: TextInputAction.next,
                                        validator: (name) {
                                          Pattern pattern =
                                              r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                                          RegExp regex = new RegExp(pattern);
                                          if (!regex.hasMatch(name))
                                            return 'Invalid name';
                                          else
                                            return null;
                                        },
                                        style: TextStyle(
                                            fontSize: 16.0,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'Montserrat'),
                                        decoration: InputDecoration(
                                          // filled: true,
                                          // fillColor: const Color(0xFFf1f1f1),
                                          hintText: '20/03/2021',
                                          contentPadding: const EdgeInsets.only(
                                              left: 14.0,
                                              bottom: 8.0,
                                              top: 8.0),
                                          focusedBorder: OutlineInputBorder(
                                              //borderSide:
                                              // BorderSide(color: const Color(0xFFf1f1f1)),
                                              // borderRadius: BorderRadius.circular(5),
                                              ),
                                          // enabledBorder: UnderlineInputBorder(
                                          //   borderSide:
                                          //       BorderSide(color: const Color(0xFFf1f1f1)),
                                          //   borderRadius: BorderRadius.circular(5),
                                          // ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 20.0),
                                    alignment: FractionalOffset.topLeft,
                                    child: Text(
                                      "Due on",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: const Color(0xFF000000),
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: GestureDetector(
                                    onTap: () {
                                      _selectDateDue(context);
                                    },
                                    child: AbsorbPointer(
                                      child: TextFormField(
                                        controller: _DueOnController,
                                        autofocus: true,
                                        keyboardType: TextInputType.name,
                                        textInputAction: TextInputAction.next,
                                        validator: (name) {
                                          Pattern pattern =
                                              r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                                          RegExp regex = new RegExp(pattern);
                                          if (!regex.hasMatch(name))
                                            return 'Invalid name';
                                          else
                                            return null;
                                        },
                                        style: TextStyle(
                                            fontSize: 16.0,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'Montserrat'),
                                        decoration: InputDecoration(
                                          // filled: true,
                                          // fillColor: const Color(0xFFf1f1f1),
                                          hintText: '20/03/2021',
                                          contentPadding: const EdgeInsets.only(
                                              left: 14.0,
                                              bottom: 8.0,
                                              top: 8.0),
                                          focusedBorder: OutlineInputBorder(
                                              //borderSide:
                                              // BorderSide(color: const Color(0xFFf1f1f1)),
                                              // borderRadius: BorderRadius.circular(5),
                                              ),
                                          // enabledBorder: UnderlineInputBorder(
                                          //   borderSide:
                                          //       BorderSide(color: const Color(0xFFf1f1f1)),
                                          //   borderRadius: BorderRadius.circular(5),
                                          // ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 20.0),
                                    alignment: FractionalOffset.topLeft,
                                    child: Text(
                                      "Discount",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: const Color(0xFF000000),
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: TextFormField(
                                    controller: _DiscountController,
                                    autofocus: true,
                                    keyboardType: TextInputType.name,
                                    textInputAction: TextInputAction.next,
                                    validator: (name) {
                                      Pattern pattern =
                                          r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                                      RegExp regex = new RegExp(pattern);
                                      if (!regex.hasMatch(name))
                                        return 'Invalid name';
                                      else
                                        return null;
                                    },
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Montserrat'),
                                    decoration: InputDecoration(
                                      // filled: true,
                                      // fillColor: const Color(0xFFf1f1f1),
                                      hintText: '5%',
                                      contentPadding: const EdgeInsets.only(
                                          left: 14.0, bottom: 8.0, top: 8.0),
                                      //focusedBorder: OutlineInputBorder(
                                      //borderSide:
                                      // BorderSide(color: const Color(0xFFf1f1f1)),
                                      // borderRadius: BorderRadius.circular(5),
                                      //),
                                      // enabledBorder: UnderlineInputBorder(
                                      //   borderSide:
                                      //       BorderSide(color: const Color(0xFFf1f1f1)),
                                      //   borderRadius: BorderRadius.circular(5),
                                      // ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 20.0),
                                    alignment: FractionalOffset.topLeft,
                                    child: Text(
                                      "Shipping fee",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: const Color(0xFF000000),
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: TextFormField(
                                    controller: _ShippingFeeController,
                                    autofocus: true,
                                    keyboardType: TextInputType.name,
                                    textInputAction: TextInputAction.next,
                                    validator: (name) {
                                      Pattern pattern =
                                          r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                                      RegExp regex = new RegExp(pattern);
                                      if (!regex.hasMatch(name))
                                        return 'Invalid name';
                                      else
                                        return null;
                                    },
                                    style: TextStyle(
                                        fontSize: 16.0,
                                        color: Colors.black,
                                        fontWeight: FontWeight.w600,
                                        fontFamily: 'Montserrat'),
                                    decoration: InputDecoration(
                                      // filled: true,
                                      // fillColor: const Color(0xFFf1f1f1),
                                      hintText: '10.00',
                                      contentPadding: const EdgeInsets.only(
                                          left: 14.0, bottom: 8.0, top: 8.0),
                                      //focusedBorder: OutlineInputBorder(
                                      //borderSide:
                                      // BorderSide(color: const Color(0xFFf1f1f1)),
                                      // borderRadius: BorderRadius.circular(5),
                                      //),
                                      // enabledBorder: UnderlineInputBorder(
                                      //   borderSide:
                                      //       BorderSide(color: const Color(0xFFf1f1f1)),
                                      //   borderRadius: BorderRadius.circular(5),
                                      // ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Container(
                        child: Container(
                          margin: const EdgeInsets.only(left: 20.0),
                          alignment: FractionalOffset.topLeft,
                          child: Text(
                            "sales Tax is",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const Color(0xFF000000),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: Container(
                          decoration: new BoxDecoration(
                            color: const Color(0xFFf1f1f1),
                            border: Border(
                              right: BorderSide(
                                  width: 1, color: const Color(0xFFf1f1f1)),
                            ),
                          ),
                          height: 45.0,
                          margin: const EdgeInsets.all(3.0),
                          width: 300.0,
                          child: DropdownButtonHideUnderline(
                            child: ButtonTheme(
                              alignedDropdown: true,
                              child: DropdownButton(
                                // iconSize: 0.0,
                                value: _selectedsalestax,
                                items: _salestaxdates.map((String value) {
                                  return new DropdownMenuItem<String>(
                                      value: value,
                                      child: new Text(
                                        value,
                                        style: TextStyle(fontSize: 12.0),
                                      ));
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _selectedsalestax = value;
                                  });
                                },
                                // ignore: deprecated_member_use
                                style: Theme.of(context).textTheme.title,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                // Container(
                //   child: Container(
                //     margin: const EdgeInsets.only(left: 20.0),
                //     alignment: FractionalOffset.topLeft,
                //     child: Text(
                //       "Total PKR:0.00",
                //       textAlign: TextAlign.center,
                //       style: TextStyle(
                //           color: const Color(0xFF000000),
                //           fontSize: 16,
                //           fontWeight: FontWeight.w600,
                //           fontFamily: 'Montserrat'),
                //     ),
                //   ),
                // ),
                Padding(
                  padding: EdgeInsets.all(10),
                  child: TextFormField(
                    controller: _PriceController,
                    autofocus: true,
                    keyboardType: TextInputType.name,
                    textInputAction: TextInputAction.next,
                    validator: (name) {
                      Pattern pattern = r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                      RegExp regex = new RegExp(pattern);
                      if (!regex.hasMatch(name))
                        return 'Invalid name';
                      else
                        return null;
                    },
                    style: TextStyle(
                        fontSize: 16.0,
                        color: Colors.black,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Montserrat'),
                    decoration: InputDecoration(
                      // filled: true,
                      // fillColor: const Color(0xFFf1f1f1),
                      hintText: 'PKR 0.00',
                      contentPadding: const EdgeInsets.only(
                          left: 14.0, bottom: 8.0, top: 8.0),
                      focusedBorder: OutlineInputBorder(
                          //borderSide:
                          // BorderSide(color: const Color(0xFFf1f1f1)),
                          // borderRadius: BorderRadius.circular(5),
                          ),
                      // enabledBorder: UnderlineInputBorder(
                      //   borderSide:
                      //       BorderSide(color: const Color(0xFFf1f1f1)),
                      //   borderRadius: BorderRadius.circular(5),
                      // ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(0),
                  ),
                  elevation: 2,
                  child: Column(
                    children: [
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _MessageToCustomerController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: (name) {
                            Pattern pattern =
                                r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(name))
                              return 'Invalid name';
                            else
                              return null;
                          },
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Message to customer',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: TextFormField(
                          controller: _MessageOnStatementController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: (name) {
                            Pattern pattern =
                                r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(name))
                              return 'Invalid name';
                            else
                              return null;
                          },
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Message on statement',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _selectedCustomer {
  final String name;
  final String id;
  final String code;
  _selectedCustomer(this.id, this.name, this.code);
}
