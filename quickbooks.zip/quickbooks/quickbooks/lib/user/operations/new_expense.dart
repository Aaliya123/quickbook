import 'package:flutter/material.dart';
import 'package:progress_dialog/progress_dialog.dart';
import 'package:quickbooks/config/palette.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:quickbooks/user/user_menu/expenses.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants.dart';

class NewExpense extends StatefulWidget {
  NewExpense({Key key}) : super(key: key);
  @override
  _NewExpense createState() => _NewExpense();
}

class _NewExpense extends State<NewExpense> {
  String _selectedCountryCode = ' No set';
  List<String> _countryCodes = [
    ' No set',
    ' Income',
    ' Expense',
    ' Credit card',
    ' Bank',
    ' Fixed assets',
    ' Account receivable',
    ' Equity',
    ' Other current assets',
  ];
  String _selecteddate = ' 19/03/2021';
  List<String> _dates = [
    ' 19/03/2021',
    ' 20/03/2021',
    ' 21/03/2021',
    ' 22/03/2021',
    ' 23/03/2021',
    ' 27/03/2021',
    ' 28/03/2021',
    ' 29/03/2021',
    ' 30/03/2021',
    ' 31/03/2021',
    ' 01/04/2021',
    ' 02/04/2021',
    ' 02/04/2021',
  ];
  String _selectedduedate = ' 19/03/2021';
  List<String> _duedates = [
    ' 19/03/2021',
    ' 20/03/2021',
    ' 21/03/2021',
    ' 22/03/2021',
    ' 23/03/2021',
    ' 27/03/2021',
    ' 28/03/2021',
    ' 29/03/2021',
    ' 30/03/2021',
    ' 31/03/2021',
    ' 01/04/2021',
    ' 02/04/2021',
    ' 02/04/2021',
  ];
  String _selectedsalestax = ' No set';
  List<String> _salestaxdates = [
    ' No set',
    ' Income',
    ' Expense',
    ' Credit card',
    ' Bank',
    ' Fixed assets',
    ' Account receivable',
    ' Equity',
    ' Other current assets',
  ];
  String _selectedmethod = ' Cash';
  List<String> _method = [' Cash', ' Cheque', ' Credit'];

  final _RefController = TextEditingController();
  final _DateController = TextEditingController();
  final _MessageOnStatementController = TextEditingController();

  Future Add_newexpense() async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    final uri = Uri.parse(base_url + "new_expense.php");
    var request = http.MultipartRequest('POST', uri);
    request.fields['who_you_paid'] = _selectedCountryCode;
    request.fields['date'] = _DateController.text;
    request.fields['method'] = _selectedmethod;
    request.fields['sale_tax'] = _selectedsalestax;
    request.fields['price'] = '';
    request.fields['ref'] = _RefController.text;
    request.fields['mess_to_state'] = _MessageOnStatementController.text;
    request.fields['auth_key'] = auth_key;
    request.fields['company_id'] = user_id;
    var response = await request.send().then((result) async {
      http.Response.fromStream(result).then((response) {
        if (response.body == "registered") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Expense added successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);

          var route = new MaterialPageRoute(
              builder: (BuildContext context) => new Expenses());
          Navigator.of(context).push(route);
          //
        } else if (response.body == "Access forbidden") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Access forbidden",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Connection Error") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Connection Error",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else {
          dialog.hide();
          Fluttertoast.showToast(
              msg: response.body,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      });
    });
  }

  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(2015),
        lastDate: DateTime(2050));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        _DateController.text =
            "${currentDate.day}-${currentDate.month}-${currentDate.year}";
      });
  }
    
String user_id;
  @override
  Future<void> initState() {
    super.initState();
    getStringValuesSF();
  }

  getStringValuesSF() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    user_id = prefs.getString('id');
    setState(() {});
  }


  @override
  Widget build(BuildContext context) {
    var countryDropDown = Container(
      decoration: new BoxDecoration(
        color: const Color(0xFFf1f1f1),
        border: Border(
          right: BorderSide(width: 0.5, color: const Color(0xFFf1f1f1)),
        ),
      ),
      // height: 45.0,

      // margin: const EdgeInsets.all(3.0),

      child: DropdownButtonHideUnderline(
        child: ButtonTheme(
          alignedDropdown: false,
          child: DropdownButton(
            // iconSize: 0.0,

            value: _selectedCountryCode,
            items: _countryCodes.map((String value) {
              return new DropdownMenuItem<String>(
                  value: value,
                  child: new Text(
                    value,
                    style: TextStyle(fontSize: 12.0),
                  ));
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedCountryCode = value;
              });
            },
            // ignore: deprecated_member_use
            style: Theme.of(context).textTheme.title,
          ),
        ),
      ),
    );
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Color(0xFFf1f1f1).withOpacity(0.9),
      appBar: AppBar(
        backgroundColor: Palette.appbar,
        elevation: 0.0,
        title: Text(
          'New expense',
          style: TextStyle(color: Colors.black, fontFamily: 'Montserrat'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Palette.main),
          iconSize: 28.0,
          onPressed: () {
            Navigator.of(context).pop();
            setState(() {});
          },
        ),
        actions: <Widget>[
          // IconButton(
          //   icon: const Icon(Icons.no_meals_rounded, color: Palette.main),
          //   iconSize: 28.0,
          //   onPressed: () {
          //     setState(() {});
          //   },
          // ),
          IconButton(
            icon: const Icon(Icons.save, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {
                Add_newexpense();
              });
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(5),
          child: Container(
            child: Column(
              children: [
                // SizedBox(height: 10),
                // Container(
                //   child: Container(
                //     margin: const EdgeInsets.only(left: 20.0),
                //     alignment: FractionalOffset.topLeft,
                //     child: Text(
                //       "Personal info",
                //       textAlign: TextAlign.center,
                //       style: TextStyle(
                //           color: const Color(0xFF000000),
                //           fontSize: 16,
                //           fontWeight: FontWeight.w600,
                //           fontFamily: 'Montserrat'),
                //     ),
                //   ),
                // ),

                // SizedBox(height: 30),
                // Container(
                //   child: Container(
                //     margin: const EdgeInsets.only(left: 20.0),
                //     alignment: FractionalOffset.topLeft,
                //     child: Text(
                //       "Contact details",
                //       textAlign: TextAlign.center,
                //       style: TextStyle(
                //           color: const Color(0xFF000000),
                //           fontSize: 16,
                //           fontWeight: FontWeight.w600,
                //           fontFamily: 'Montserrat'),
                //     ),
                //   ),
                // ),
                Card(
                  child: Column(
                    children: [
                      SizedBox(height: 20),
                      Container(
                        child: Container(
                          margin: const EdgeInsets.only(left: 20.0),
                          alignment: FractionalOffset.topLeft,
                          child: Text(
                            "Who you paid",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const Color(0xFF000000),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: Container(
                          decoration: new BoxDecoration(
                            color: const Color(0xFFf1f1f1),
                            border: Border(
                              right: BorderSide(
                                  width: 1, color: const Color(0xFFf1f1f1)),
                            ),
                          ),
                          height: 45.0,
                          margin: const EdgeInsets.all(3.0),
                          width: 300.0,
                          child: DropdownButtonHideUnderline(
                            child: ButtonTheme(
                              alignedDropdown: true,
                              child: DropdownButton(
                                // iconSize: 0.0,
                                value: _selectedCountryCode,
                                items: _countryCodes.map((String value) {
                                  return new DropdownMenuItem<String>(
                                      value: value,
                                      child: new Text(
                                        value,
                                        style: TextStyle(fontSize: 12.0),
                                      ));
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _selectedCountryCode = value;
                                  });
                                },
                                // ignore: deprecated_member_use
                                style: Theme.of(context).textTheme.title,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 20.0),
                                    alignment: FractionalOffset.topLeft,
                                    child: Text(
                                      "Date",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: const Color(0xFF000000),
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: GestureDetector(
                                    onTap: () {
                                      _selectDate(context);
                                    },
                                    child: AbsorbPointer(
                                      child: TextFormField(
                                        controller: _DateController,
                                        autofocus: true,
                                        keyboardType: TextInputType.name,
                                        textInputAction: TextInputAction.next,
                                        validator: (name) {
                                          Pattern pattern =
                                              r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                                          RegExp regex = new RegExp(pattern);
                                          if (!regex.hasMatch(name))
                                            return 'Invalid name';
                                          else
                                            return null;
                                        },
                                        style: TextStyle(
                                            fontSize: 16.0,
                                            color: Colors.black,
                                            fontWeight: FontWeight.w600,
                                            fontFamily: 'Montserrat'),
                                        decoration: InputDecoration(
                                          // filled: true,
                                          // fillColor: const Color(0xFFf1f1f1),
                                          hintText: '20/03/2021',
                                          contentPadding: const EdgeInsets.only(
                                              left: 14.0,
                                              bottom: 8.0,
                                              top: 8.0),
                                          focusedBorder: OutlineInputBorder(
                                              //borderSide:
                                              // BorderSide(color: const Color(0xFFf1f1f1)),
                                              // borderRadius: BorderRadius.circular(5),
                                              ),
                                          // enabledBorder: UnderlineInputBorder(
                                          //   borderSide:
                                          //       BorderSide(color: const Color(0xFFf1f1f1)),
                                          //   borderRadius: BorderRadius.circular(5),
                                          // ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                Container(
                                  child: Container(
                                    margin: const EdgeInsets.only(left: 20.0),
                                    alignment: FractionalOffset.topLeft,
                                    child: Text(
                                      "Method",
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                          color: const Color(0xFF000000),
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.all(5),
                                  child: Container(
                                    decoration: new BoxDecoration(
                                      color: const Color(0xFFf1f1f1),
                                      border: Border(
                                        right: BorderSide(
                                            width: 1,
                                            color: const Color(0xFFf1f1f1)),
                                      ),
                                    ),
                                    height: 45.0,
                                    margin: const EdgeInsets.all(3.0),
                                    width: 300.0,
                                    child: DropdownButtonHideUnderline(
                                      child: ButtonTheme(
                                        alignedDropdown: true,
                                        child: DropdownButton(
                                          // iconSize: 0.0,
                                          value: _selectedmethod,
                                          items: _method.map((String value) {
                                            return new DropdownMenuItem<String>(
                                                value: value,
                                                child: new Text(
                                                  value,
                                                  style:
                                                      TextStyle(fontSize: 12.0),
                                                ));
                                          }).toList(),
                                          onChanged: (value) {
                                            setState(() {
                                              _selectedmethod = value;
                                            });
                                          },
                                          // ignore: deprecated_member_use
                                          style:
                                              Theme.of(context).textTheme.title,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 20),
                      Container(
                        child: Container(
                          margin: const EdgeInsets.only(left: 20.0),
                          alignment: FractionalOffset.topLeft,
                          child: Text(
                            "sales Tax is",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const Color(0xFF000000),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: Container(
                          decoration: new BoxDecoration(
                            color: const Color(0xFFf1f1f1),
                            border: Border(
                              right: BorderSide(
                                  width: 1, color: const Color(0xFFf1f1f1)),
                            ),
                          ),
                          height: 45.0,
                          margin: const EdgeInsets.all(3.0),
                          width: 300.0,
                          child: DropdownButtonHideUnderline(
                            child: ButtonTheme(
                              alignedDropdown: true,
                              child: DropdownButton(
                                // iconSize: 0.0,
                                value: _selectedsalestax,
                                items: _salestaxdates.map((String value) {
                                  return new DropdownMenuItem<String>(
                                      value: value,
                                      child: new Text(
                                        value,
                                        style: TextStyle(fontSize: 12.0),
                                      ));
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    _selectedsalestax = value;
                                  });
                                },
                                // ignore: deprecated_member_use
                                style: Theme.of(context).textTheme.title,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20),
                      Container(
                        child: Container(
                          margin: const EdgeInsets.only(left: 20.0),
                          alignment: FractionalOffset.topLeft,
                          child: Text(
                            "Total PKR:0.00",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                color: const Color(0xFF000000),
                                fontSize: 16,
                                fontWeight: FontWeight.w600,
                                fontFamily: 'Montserrat'),
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      Padding(
                        padding: EdgeInsets.all(10),
                        child: TextFormField(
                          controller: _RefController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: (name) {
                            Pattern pattern =
                                r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(name))
                              return 'Invalid name';
                            else
                              return null;
                          },
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Ref #',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(5),
                        child: TextFormField(
                          controller: _MessageOnStatementController,
                          autofocus: true,
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          validator: (name) {
                            Pattern pattern =
                                r'^[A-Za-z0-9]+(?:[ _-][A-Za-z0-9]+)*$';
                            RegExp regex = new RegExp(pattern);
                            if (!regex.hasMatch(name))
                              return 'Invalid name';
                            else
                              return null;
                          },
                          style: TextStyle(
                              fontSize: 16.0,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Montserrat'),
                          decoration: InputDecoration(
                            // filled: true,
                            // fillColor: const Color(0xFFf1f1f1),
                            hintText: 'Message on statement',
                            contentPadding: const EdgeInsets.only(
                                left: 14.0, bottom: 8.0, top: 8.0),
                            focusedBorder: OutlineInputBorder(
                                //borderSide:
                                // BorderSide(color: const Color(0xFFf1f1f1)),
                                // borderRadius: BorderRadius.circular(5),
                                ),
                            // enabledBorder: UnderlineInputBorder(
                            //   borderSide:
                            //       BorderSide(color: const Color(0xFFf1f1f1)),
                            //   borderRadius: BorderRadius.circular(5),
                            // ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
