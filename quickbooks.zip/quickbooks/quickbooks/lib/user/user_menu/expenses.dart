import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/user/operations/new_expense.dart';

class Expenses extends StatefulWidget {
  Expenses({Key key}):super(key: key);
  @override
  _Expenses createState() => _Expenses();
}

class _Expenses extends State<Expenses> {


  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
         backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Expenses',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {});
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.search, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
          ],
      ),
      body:Container(
        child: Center(child: Text("See ehat you spend",
        style: TextStyle(fontSize: 25,fontWeight:FontWeight.w600,fontFamily: 'Montserrat'),),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          var route = new MaterialPageRoute(
              builder: (BuildContext context) => new NewExpense());
          Navigator.of(context).push(route);
        },
        child: Icon(Icons.add),
        backgroundColor: Palette.main,
      ),
    );
  }
   
  

}

