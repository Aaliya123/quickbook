import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'package:quickbooks/user/details/sales_reciept_details.dart';
import 'package:quickbooks/user/details/vendor_details.dart';
import 'package:quickbooks/user/menu.dart';
import 'package:quickbooks/user/operations/new_sales_receipt.dart';
import 'dart:convert';

import 'package:quickbooks/user/operations/new_vendor.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants.dart';

class SalesReceipt extends StatefulWidget {
  SalesReceipt({Key key}):super(key: key);
  @override
  _SalesReceipt createState() => _SalesReceipt();
}

class _SalesReceipt extends State<SalesReceipt> {

Future<List<sales_item>> _GetSales() async {
    var Users =
        await http.get(base_url+"getsalesreceipt.php?auth_key=$auth_key&company_id=$user_id");
    var JsonData = json.decode(Users.body);
    List<sales_item> sales = [];
    for (var u in JsonData) {
      sales_item item = sales_item(
          u["sale_receipt_id"],
          u["cus_name"],
          u["method"],
          u["date"],
          u["sr_no"],
          u["sales_tax"],
          u["price"],
          u["mess_to_cus"],
          u["mess_to_state"],
          u["code"]);
      sales.add(item);
    }
    // Fluttertoast.showToast(
    //       msg: '$users',
    //       toastLength: Toast.LENGTH_SHORT,
    //       gravity: ToastGravity.CENTER,
    //       timeInSecForIosWeb: 1,
    //       backgroundColor: Colors.red,
    //       textColor: Colors.white,
    //       fontSize: 16.0
    //   );
    return sales;
  }

  
  
String user_id;
  @override
  Future<void> initState() {
    super.initState();
    getStringValuesSF();
  }

  getStringValuesSF() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    user_id = prefs.getString('id');
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Sales Receipt',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              var route = new MaterialPageRoute(
              builder: (BuildContext context) => new UserMenu());
          Navigator.of(context).push(route);
            setState(() {});
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.search, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
            // IconButton(
            //   icon: const Icon(Icons.no_meals_rounded, color: Palette.main),
            //   iconSize: 28.0,
            //   onPressed: () {
            //     setState(() {});
            //   },
            // ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
          ],
      ),
      body: Container(
        child:FutureBuilder(
          future:_GetSales(),
          builder: (BuildContext context, AsyncSnapshot snapshot){
            if(snapshot.data==null){
              return Container(
                child: Center(
                child:Text("Loading...")
                ),
              );
            }
            else if(snapshot.data[0].code==0){
                return Container(
                child: Center(
                child:Text("No Users")
                ),
              );
            }
            else{
              return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (BuildContext context , int index){
                return InkWell(
                  onTap: (){
                  //    var route=new MaterialPageRoute(
                  //   builder:(BuildContext context)=>
                  //  new UserDetails(
                  //   user_id:snapshot.data[index].id,
                  //   user_name:snapshot.data[index].user_name,
                  //   user_email:snapshot.data[index].user_email,
                  //   user_mobile:snapshot.data[index].user_mobile,
                  //   user_profile:snapshot.data[index].user_profile,
                  //   user_active:snapshot.data[index].active,
                  //   ));
                  //   Navigator.of(context).push(route);
                  var route = new MaterialPageRoute(
                            builder: (BuildContext context) => new SalesReceiptDetails(
                                sale_receipt_id: snapshot.data[index].sale_receipt_id,
                                cus_name: snapshot.data[index].cus_name,
                                method: snapshot.data[index].method,
                                sr_no: snapshot.data[index].sr_no,
                                date: snapshot.data[index].date,
                                sales_tax: snapshot.data[index].sales_tax,
                                price: snapshot.data[index].price,
                                mess_to_cus: snapshot.data[index].mess_to_cus,
                                mess_to_state: snapshot.data[index].mess_to_state));
                        Navigator.of(context).push(route);
                  },
                  child: Container(
                    width:MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(horizontal:10.0,vertical: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(children: [
                            SizedBox(width:10.0),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(snapshot.data[index].cus_name,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Montserrat'),
                                  ),
                                  Text(snapshot.data[index].sale_receipt_id,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Montserrat'),
                                  ),
                                
                              ],
                            ),
                          ],
                        ),
                         SizedBox(width:10.0),
                      ],
                    ),
                  ),
                );
              },
            );
            }
            
          }
          ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
             var route=new MaterialPageRoute(
                    builder:(BuildContext context)=>
                   new NewISalesRecipt());
                    Navigator.of(context).push(route);
        },
        child: Icon(Icons.add),
        backgroundColor: Palette.main,
      ),
    );
  }
  

}

class sales_item {
  final String sale_receipt_id;
  final String cus_name;
  final String method;
  final String date;
  final String sr_no;
  final String sales_tax;
  final String price;
  final String mess_to_cus;
  final String mess_to_state;
  final int code;

  sales_item(this.sale_receipt_id,this.cus_name,this.method,this.date,this.sr_no,this.sales_tax,this.price,this.mess_to_cus,this.mess_to_state,this.code);
}
