import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:http/http.dart' as http;
import 'package:quickbooks/user/menu.dart';
import 'package:quickbooks/user/operations/new_invoice_payment.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../constants.dart';

class InvoicePayments extends StatefulWidget {
  InvoicePayments({Key key}):super(key: key);
  @override
  _InvoicePayments createState() => _InvoicePayments();
}

class _InvoicePayments extends State<InvoicePayments> {


Future<List<invoice_item>> _GetInvoices() async {
    var Users =
        await http.get(base_url+"getInvoicePayment.php?auth_key=$auth_key&company_id=$user_id");
    var JsonData = json.decode(Users.body);
    List<invoice_item> invoice = [];
    for (var u in JsonData) {
      invoice_item item = invoice_item(
          u["invoice_payment_id"],
          u["cutomer"],
          u["method"],
          u["date"],
          u["ref_no"],
          u["amount"],
          u["unapp_amount"],
          u["mess_to_cus"],
          u["code"]);
      invoice.add(item);
    }
    // Fluttertoast.showToast(
    //       msg: '$users',
    //       toastLength: Toast.LENGTH_SHORT,
    //       gravity: ToastGravity.CENTER,
    //       timeInSecForIosWeb: 1,
    //       backgroundColor: Colors.red,
    //       textColor: Colors.white,
    //       fontSize: 16.0
    //   );
    return invoice;
  }
  
  
String user_id;
  @override
  Future<void> initState() {
    super.initState();
    getStringValuesSF();
  }

  getStringValuesSF() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    user_id = prefs.getString('id');
    setState(() {});
  }


  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Invoices',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              var route = new MaterialPageRoute(
              builder: (BuildContext context) => new UserMenu());
          Navigator.of(context).push(route);
            setState(() {});
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.search, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
            // IconButton(
            //   icon: const Icon(Icons.no_meals_rounded, color: Palette.main),
            //   iconSize: 28.0,
            //   onPressed: () {
            //     setState(() {});
            //   },
            // ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
          ],
      ),
      body: Container(
        child:FutureBuilder(
          future:_GetInvoices(),
          builder: (BuildContext context, AsyncSnapshot snapshot){
            if(snapshot.data==null){
              return Container(
                child: Center(
                child:Text("Loading...")
                ),
              );
            }
            else if(snapshot.data[0].code==0){
                return Container(
                child: Center(
                child:Text("No Users")
                ),
              );
            }
            else{
              return ListView.builder(
              itemCount: snapshot.data.length,
              itemBuilder: (BuildContext context , int index){
                return InkWell(
                  onTap: (){
                  //    var route=new MaterialPageRoute(
                  //   builder:(BuildContext context)=>
                  //  new UserDetails(
                  //   user_id:snapshot.data[index].id,
                  //   user_name:snapshot.data[index].user_name,
                  //   user_email:snapshot.data[index].user_email,
                  //   user_mobile:snapshot.data[index].user_mobile,
                  //   user_profile:snapshot.data[index].user_profile,
                  //   user_active:snapshot.data[index].active,
                  //   ));
                  //   Navigator.of(context).push(route);
                  // var route = new MaterialPageRoute(
                  //           builder: (BuildContext context) => new InvoiceDetails(
                  //               invoice_id: snapshot.data[index].invoice_id,
                  //               cus_name: snapshot.data[index].cus_name,
                  //               invoice_no: snapshot.data[index].invoice_no,
                  //               date: snapshot.data[index].date,
                  //               due_on: snapshot.data[index].due_on,
                  //               discount: snapshot.data[index].discount,
                  //               shipping_fee: snapshot.data[index].shipping_fee,
                  //               sales_tax: snapshot.data[index].sales_tax,
                  //               price: snapshot.data[index].price,
                  //               mess_to_cus: snapshot.data[index].mess_to_cus,
                  //               mess_to_state: snapshot.data[index].mess_to_state));
                  //       Navigator.of(context).push(route);
                  },
                  child: Container(
                    width:MediaQuery.of(context).size.width,
                    padding: EdgeInsets.symmetric(horizontal:10.0,vertical: 10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(children: [
                            SizedBox(width:10.0),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(snapshot.data[index].cutomer,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    fontFamily: 'Montserrat'),
                                  ),
                                  Text(snapshot.data[index].method,
                                style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 12,
                                    fontWeight: FontWeight.w800,
                                    fontFamily: 'Montserrat'),
                                  ),
                                
                              ],
                            ),
                          ],
                        ),
                         SizedBox(width:10.0),
                      ],
                    ),
                  ),
                );
              },
            );
            }
            
          }
          ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: (){
             var route=new MaterialPageRoute(
                    builder:(BuildContext context)=>
                   new NewInvoicePayment());
                    Navigator.of(context).push(route);
        },
        child: Icon(Icons.add),
        backgroundColor: Palette.main,
      ),
    );
  }
   
  

}

class invoice_item {
  final String invoice_payment_id;
  final String cutomer;
  final String method;
  final String date;
  final String ref_no;
  final String amount;
  final String unapp_amount;
  final String mess_to_cus;
  final int code;

  invoice_item(this.invoice_payment_id,this.cutomer,this.method,this.date,this.ref_no,this.amount,this.unapp_amount,this.mess_to_cus,this.code);
}
