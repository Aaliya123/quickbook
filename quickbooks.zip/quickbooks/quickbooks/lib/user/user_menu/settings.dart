import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';

class Settings extends StatefulWidget {
  Settings({Key key}):super(key: key);
  @override
  _Settings createState() => _Settings();
}

class _Settings extends State<Settings> {


  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Settings',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {});
            },
          ),
          actions: <Widget>[
            
            IconButton(
              icon: const Icon(Icons.more_vert, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
          ],
      ),
      body:Container(

      ),
    );
  }
   
  

}

