import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';

class Help extends StatefulWidget {
  Help({Key key}):super(key: key);
  @override
  _Help createState() => _Help();
}

class _Help extends State<Help> {


  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Help',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {});
            },
          ),
      ),
      body:Container(

      ),
    );
  }
   
  

}

