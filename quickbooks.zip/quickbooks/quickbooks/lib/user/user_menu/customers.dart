import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/user/details/user_details.dart';
import 'package:quickbooks/user/menu.dart';
import 'package:quickbooks/user/operations/add_customer.dart';
import 'package:quickbooks/constants.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class Customer extends StatefulWidget {
  Customer({Key key}) : super(key: key);
  @override
  _Customer createState() => _Customer();
}

class _Customer extends State<Customer> {
  Future<List<user_item>> _GetUsers() async {
    var Users = await http.get(
        base_url + "getcustomers.php?auth_key=$auth_key&user_id='$user_id'");
    var JsonData = json.decode(Users.body);
    List<user_item> users = [];
    for (var u in JsonData) {
      user_item item = user_item(
          u["id"],
          u["name"],
          u["company_name"],
          u["phone"],
          u["mobile"],
          u["fax"],
          u["email"],
          u["address1"],
          u["address2"],
          u["address3"],
          u["city"],
          u["state"],
          u["zip"],
          u["country"],
          u["code"]);
      users.add(item);
    }
    // Fluttertoast.showToast(
    //       msg: '$users',
    //       toastLength: Toast.LENGTH_SHORT,
    //       gravity: ToastGravity.CENTER,
    //       timeInSecForIosWeb: 1,
    //       backgroundColor: Colors.red,
    //       textColor: Colors.white,
    //       fontSize: 16.0
    //   );
    return users;
  }

  String user_id;
  @override
  Future<void> initState() {
    super.initState();
    getStringValuesSF();
  }

  getStringValuesSF() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    user_id = prefs.getString('id');
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Palette.appbar,
        elevation: 0.0,
        title: Text(
          'Customers',
          style: TextStyle(color: Colors.black, fontFamily: 'Montserrat'),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Palette.main),
          iconSize: 28.0,
          onPressed: () {
            var route = new MaterialPageRoute(
                builder: (BuildContext context) => new UserMenu());
            Navigator.of(context).push(route);
            setState(() {});
          },
        ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.search, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {});
            },
          ),
          // IconButton(
          //   icon: const Icon(Icons.no_meals_rounded, color: Palette.main),
          //   iconSize: 28.0,
          //   onPressed: () {
          //     setState(() {});
          //   },
          // ),
          IconButton(
            icon: const Icon(Icons.more_vert, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {});
            },
          ),
        ],
      ),
      body: Container(
        child: FutureBuilder(
            future: _GetUsers(),
            builder: (BuildContext context, AsyncSnapshot snapshot) {
              if (snapshot.data == null) {
                return Container(
                  child: Center(child: Text("Loading...")),
                );
              } else if (snapshot.data[0].code == 0) {
                return Container(
                  child: Center(child: Text("No Users")),
                );
              } else {
                return ListView.builder(
                  itemCount: snapshot.data.length,
                  itemBuilder: (BuildContext context, int index) {
                    return InkWell(
                      onTap: () {
                        //    var route=new MaterialPageRoute(
                        //   builder:(BuildContext context)=>
                        //  new UserDetails(
                        //   user_id:snapshot.data[index].id,
                        //   user_name:snapshot.data[index].user_name,
                        //   user_email:snapshot.data[index].user_email,
                        //   user_mobile:snapshot.data[index].user_mobile,
                        //   user_profile:snapshot.data[index].user_profile,
                        //   user_active:snapshot.data[index].active,
                        //   ));
                        //   Navigator.of(context).push(route);
                        var route = new MaterialPageRoute(
                            builder: (BuildContext context) => new UserDetails(
                                id: snapshot.data[index].id,
                                name: snapshot.data[index].name,
                                company_name: snapshot.data[index].company_name,
                                phone: snapshot.data[index].phone,
                                mobile: snapshot.data[index].mobile,
                                fax: snapshot.data[index].fax,
                                email: snapshot.data[index].email,
                                address1: snapshot.data[index].address1,
                                address2: snapshot.data[index].address2,
                                address3: snapshot.data[index].address3,
                                city: snapshot.data[index].city,
                                state: snapshot.data[index].state,
                                zip: snapshot.data[index].zip,
                                country: snapshot.data[index].country));
                        Navigator.of(context).push(route);
                      },
                      child: Container(
                        width: MediaQuery.of(context).size.width,
                        padding: EdgeInsets.symmetric(
                            horizontal: 10.0, vertical: 10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Row(
                              children: [
                                SizedBox(width: 10.0),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    new Text(
                                      snapshot.data[index].name,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 18,
                                          fontWeight: FontWeight.w600,
                                          fontFamily: 'Montserrat'),
                                    ),
                                    new Text(
                                      snapshot.data[index].email,
                                      style: TextStyle(
                                          color: Colors.black,
                                          fontSize: 12,
                                          fontWeight: FontWeight.w800,
                                          fontFamily: 'Montserrat'),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(width: 10.0),
                          ],
                        ),
                      ),
                    );
                  },
                );
              }
            }),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          var route = new MaterialPageRoute(
              builder: (BuildContext context) => new AddCustomer());
          Navigator.of(context).push(route);
        },
        child: Icon(Icons.add),
        backgroundColor: Palette.main,
      ),
    );
  }
}

class user_item {
  final String id;
  final String name;
  final String company_name;
  final String phone;
  final String mobile;
  final String fax;
  final String email;
  final String address1;
  final String address2;
  final String address3;
  final String city;
  final String state;
  final String zip;
  final String country;
  final int code;

  user_item(
      this.id,
      this.name,
      this.company_name,
      this.phone,
      this.mobile,
      this.fax,
      this.email,
      this.address1,
      this.address2,
      this.address3,
      this.city,
      this.state,
      this.zip,
      this.country,
      this.code);
}
