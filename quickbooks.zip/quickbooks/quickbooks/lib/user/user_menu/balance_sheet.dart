import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';

class BalanceSheet extends StatefulWidget {
  BalanceSheet({Key key}):super(key: key);
  @override
  _BalanceSheet createState() => _BalanceSheet();
}

class _BalanceSheet extends State<BalanceSheet> {

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Balance Sheet',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {});
            },
          ),
          actions: <Widget>[
            
            IconButton(
              icon: const Icon(Icons.more_vert, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
          ],
      ),
      body:Container(
        child: Center(child: Text("Your balance sheet",
        style: TextStyle(fontSize: 25,fontWeight:FontWeight.w600,fontFamily: 'Montserrat'),),
        ),
      ),
    );
  }
   
  

}

