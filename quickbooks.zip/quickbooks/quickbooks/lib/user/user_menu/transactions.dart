import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/components/rounded_button.dart';

class Transactions extends StatefulWidget {
  Transactions({Key key}):super(key: key);
  @override
  _Transactions createState() => _Transactions();
}

class _Transactions extends State<Transactions> {

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          title: Text('Transactions',
          style: TextStyle(color: Colors.black,fontFamily: 'Montserrat'),),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios,color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              Navigator.of(context).pop();
              setState(() {});
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.refresh_rounded, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
            IconButton(
              icon: const Icon(Icons.more_vert, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {});
              },
            ),
          ],
      ),
      body:Container(
              child: Center(
                child: RoundedButton(
                  text: "Connect to bank",
                  press: () {
                    setState(() {});
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //     builder: (context) {
                    //       return User();
                    //     },
                    //   ),
                    // );
                  },
                ),
              ),
            ),
    );
  }
   
  

}

