import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/user/menu.dart';
import 'package:quickbooks/config/styles.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:quickbooks/components/rounded_button.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:quickbooks/user/user_menu/settings.dart';
import 'package:quickbooks/user/user_menu/help.dart';
// class UserDashboard extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: MyHomePage(title: 'Assad'),
//     );
//   }
// }

class UserDashboard extends StatefulWidget {
  UserDashboard({Key key}) : super(key: key);

  @override
  _UserDashboard createState() => _UserDashboard();
}

class _UserDashboard extends State<UserDashboard> {
  Future<List<user_item>> _GetUsers() async {
    var Users = await http
        .get("http://192.168.43.42/quickbooks/quickbooks/database/data.php");
    var JsonData = json.decode(Users.body);
    List<user_item> users = [];
    for (var u in JsonData) {
      user_item item = user_item(u["user_id"], u["user_name"], u["user_email"],
          u["user_mobile"], u["user_profile"], u["code"], u["active"]);
      users.add(item);
    }
    
    return users;
  }

  int _BottomBarIndex = 0;
  List<String> events = [
    "Transaction",
    "Customer",
    "Invoice",
    "Estimates",
    "Expenses",
    "Sales receipt",
    "Profit and loss",
    "Products & services"
  ];
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 0.0,
          // title: Text('All Users'),
          leading: IconButton(
            icon: const Icon(Icons.settings_outlined, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {
                var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Settings());
                      Navigator.of(context).push(route);
              });
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.help_outline_rounded, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {
                  var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Help());
                      Navigator.of(context).push(route);
                });
              },
            ),
          ],

          bottom: TabBar(
              indicatorColor: Palette.main,
              labelColor: Palette.main,
              unselectedLabelColor: Colors.grey,
              tabs: [
                Tab(text: "Dashboard"),
                Tab(text: "Activity"),
              ]),
        ),
        body: TabBarView(
          children: [
            Container(
              child: Center(
                child: RoundedButton(
                  text: "Connect to bank",
                  press: () {
                    setState(() {});
                    // Navigator.push(
                    //   context,
                    //   MaterialPageRoute(
                    //     builder: (context) {
                    //       return User();
                    //     },
                    //   ),
                    // );
                  },
                ),
              ),
            ),
            Center(
              child: FutureBuilder(
                  future: _GetUsers(),
                  builder: (BuildContext context, AsyncSnapshot snapshot) {
                    if (snapshot.data == null) {
                      return Container(
                        child: Center(child: Text("Loading...")),
                      );
                    } else if (snapshot.data[0].code == 0) {
                      return Container(
                        child: Center(child: Text("No Activities")),
                      );
                    } else {
                      return ListView.builder(
                        itemCount: snapshot.data.length,
                        itemBuilder: (BuildContext context, int index) {
                          return InkWell(
                            onTap: () {},
                            child: Container(
                              width: MediaQuery.of(context).size.width,
                              padding: EdgeInsets.symmetric(
                                  horizontal: 10.0, vertical: 10.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Row(
                                    children: [
                                      // Container(
                                      //   width: 50.0,
                                      //   height: 50.0,
                                      //   child: CircleAvatar(
                                      //     backgroundImage: NetworkImage(snapshot
                                      //         .data[index].user_profile),
                                      //   ),
                                      // ),
                                      // SizedBox(width: 10.0),
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Saad",
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 18,
                                                fontWeight: FontWeight.w600,
                                                fontFamily: 'Montserrat'),
                                          ),
                                          Text(
                                            "Invoice 335",
                                            style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 12,
                                                fontWeight: FontWeight.w800,
                                                fontFamily: 'Montserrat'),
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(width: 10.0),
                                  Container(
                                    alignment: Alignment.center,
                                    child: Chip(
                                      label: Text(
                                        "Paid",
                                        style: TextStyle(
                                            color: Colors.black,
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                            fontFamily: 'Montserrat'),
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    }
                  }),
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _BottomBarIndex,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              title: Text("Home"),
              backgroundColor: Palette.main,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.menu),
              title: Text("Menu"),
              backgroundColor: Palette.main,
            ),
          ],
          onTap: (index) {
            setState(() {
              _BottomBarIndex = index;
              if (index == 1) {
                var route = new MaterialPageRoute(
                    builder: (BuildContext context) => new UserMenu());
                Navigator.of(context).push(route);
              }
            });
          },
        ),
      ),
    );
  }
}

Column getCardByTitle(String title) {
  String img = "";
  if (title == "Transaction") {
    img = "assets/calculator.png";
  } else if (title == "Customer") {
    img = "assets/calculator.png";
  } else if (title == "Invoice") {
    img = "assets/calculator.png";
  } else if (title == "Estimates") {
    img = "assets/calculator.png";
  } else if (title == "Expenses") {
    img = "assets/ticket.png";
  } else if (title == "Sales receipt") {
    img = "assets/ticket.png";
  } else if (title == "Profit & loss") {
    img = "assets/ticket.png";
  }
  else if (title == "Products & services") {
    img = "assets/ticket.png";
  }
  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      new Center(
          child: Container(
              child: new Stack(children: [
        new Image.asset(
          img,
          width: 50.0,
          height: 50.0,
        )
      ]))),
      SizedBox(height: 10),
      Text(
        title,
        style: TextStyle(
            fontSize: 15.0, fontWeight: FontWeight.bold, color: Palette.main),
      )
    ],
  );
}

class user_item {
  final String id;
  final String user_name;
  final String user_email;
  final String user_mobile;
  final String user_profile;
  final int code;
  final String active;

  user_item(this.id, this.user_name, this.user_email, this.user_mobile,
      this.user_profile, this.code, this.active);
}
