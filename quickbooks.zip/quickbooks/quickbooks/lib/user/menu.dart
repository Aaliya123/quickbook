import 'package:flutter/material.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/user/user_menu/attachment.dart';
import 'package:quickbooks/user/user_menu/balance_sheet.dart';
import 'package:quickbooks/user/user_menu/categories.dart';
import 'package:quickbooks/user/user_menu/customers.dart';
import 'package:quickbooks/user/user_menu/estimates.dart';
import 'package:quickbooks/user/user_menu/expenses.dart';
import 'package:quickbooks/user/user_menu/help.dart';
import 'package:quickbooks/user/user_menu/invoice_payments.dart';
import 'package:quickbooks/user/user_menu/invoices.dart';
import 'package:quickbooks/user/user_menu/pofit_and_loss.dart';
import 'package:quickbooks/user/user_menu/product_and_services.dart';
import 'package:quickbooks/user/user_menu/sales_receipt.dart';
import 'package:quickbooks/user/user_menu/settings.dart';
import 'package:quickbooks/user/user_menu/transactions.dart';
import 'package:quickbooks/user/user_menu/vendors.dart';
import 'package:quickbooks/config/styles.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:quickbooks/components/rounded_button.dart';
// class UserDashboard extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Flutter Demo',
//       theme: ThemeData(
//         primarySwatch: Colors.blue,
//       ),
//       home: MyHomePage(title: 'Assad'),
//     );
//   }
// }

class UserMenu extends StatefulWidget {
  UserMenu({Key key}) : super(key: key);

  @override
  _UserMenu createState() => _UserMenu();
}

class _UserMenu extends State<UserMenu> {
  int _BottomBarIndex = 0;
  List<String> events = [
    "Transaction",
    "Customer",
    "Invoices",
    "Estimates",
    "Expenses",
    "Sales receipt",
    "Profit and loss",
    "Product & \nservices",
    "Balance sheet",
    "Categories",
    "Invoice payment",
    "Vendors",
    "Attachments",
    "Help",
    "Settings"
  ];
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Palette.appbar,
          elevation: 5.0,
          // title: Text('All Users'),
          leading: IconButton(
            icon: const Icon(Icons.settings_outlined, color: Palette.main),
            iconSize: 28.0,
            onPressed: () {
              setState(() {
                var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Settings());
                      Navigator.of(context).push(route);
              });
            },
          ),
          actions: <Widget>[
            IconButton(
              icon: const Icon(Icons.help_outline_rounded, color: Palette.main),
              iconSize: 28.0,
              onPressed: () {
                setState(() {
                  var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Help());
                      Navigator.of(context).push(route);
                });
              },
            ),
          ],
        ),
        body: Center(
          child: GridView(
              padding: EdgeInsets.all(10),
              physics: BouncingScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
              ),
              children: events.map((title) {
                return InkWell(
                  child: Card(
                    margin: const EdgeInsets.all(20.0),
                    child: getCardByTitle(title),
                  ),
                  onTap: () {
                    // Fluttertoast.showToast(
                    //     msg: "$title",
                    //     toastLength: Toast.LENGTH_SHORT,
                    //     gravity: ToastGravity.CENTER,
                    //     timeInSecForIosWeb: 1,
                    //     backgroundColor: Colors.red,
                    //     textColor: Colors.white,
                    //     fontSize: 16.0);
                    if (title == "Transaction") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) =>
                              new Transactions());
                      Navigator.of(context).push(route);
                    } else if (title == "Customer") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Customer());
                      Navigator.of(context).push(route);
                    } else if (title == "Invoices") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Invoices());
                      Navigator.of(context).push(route);
                    }
                   else if (title == "Estimates") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Estimates());
                      Navigator.of(context).push(route);
                    } 
                    else if (title == "Expenses") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Expenses());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Sales receipt") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new SalesReceipt());
                      Navigator.of(context).push(route);
                    } 
                    else if (title == "Profit and loss") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new ProfitLoss());
                      Navigator.of(context).push(route);
                    } 
                    else if (title == "Product & \nservices") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new ProductServices());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Balance sheet") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new BalanceSheet());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Categories") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Categories());
                      Navigator.of(context).push(route);
                    } 
                    else if (title == "Invoice payment") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new InvoicePayments());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Vendors") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Vendors());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Attachments") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Attachemnts());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Help") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Help());
                      Navigator.of(context).push(route);
                    }
                    else if (title == "Settings") {
                      var route = new MaterialPageRoute(
                          builder: (BuildContext context) => new Settings());
                      Navigator.of(context).push(route);
                    }
                  },
                );
              }).toList()),
        ),
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _BottomBarIndex,
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              title: Text("Home"),
              backgroundColor: Palette.main,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.menu),
              title: Text("Menu"),
              backgroundColor: Palette.main,
            ),
          ],
          onTap: (index) {
            setState(() {
              _BottomBarIndex = index;
              if (index == 0) {
                Navigator.pop(context);
              }
            });
          },
        ),
      ),
    );
  }
}

Column getCardByTitle(String title) {
  String img = "";
  if (title == "Transaction") {
    img = "assets/transaction.png";
  } else if (title == "Customer") {
    img = "assets/customer-review.png";
  } else if (title == "Invoices") {
    img = "assets/invoice.png";
  } else if (title == "Estimates") {
    img = "assets/budgeting.png";
  } else if (title == "Expenses") {
    img = "assets/bill.png";
  } else if (title == "Sales receipt") {
    img = "assets/payment.png";
  } else if (title == "Profit and loss") {
    img = "assets/profit.png";
  } else if (title == "Product & \nservices") {
    img = "assets/ticket.png";
  } else if (title == "Balance sheet") {
    img = "assets/coupon.png";
  } else if (title == "Categories") {
    img = "assets/category.png";
  } else if (title == "Invoice payment") {
    img = "assets/invoice.png";
  } else if (title == "Vendors") {
    img = "assets/hotel-supplier.png";
  } else if (title == "Attachments") {
    img = "assets/paper-clip.png";
  } else if (title == "Help") {
    img = "assets/customer-support.png";
  } else if (title == "Settings") {
    img = "assets/cogwheel.png";
  }

  return Column(
    mainAxisAlignment: MainAxisAlignment.center,
    children: [
      new Center(
          child: Container(
              child: new Stack(children: [
        new Image.asset(
          img,
          width: 50.0,
          height: 50.0,
        )
      ]))),
      SizedBox(height: 10),
      Text(
        title,
        style: TextStyle(color: Colors.black,fontFamily: 'Montserrat',fontWeight: FontWeight.w600,fontSize: 13),),
      
    ],
  );
}
