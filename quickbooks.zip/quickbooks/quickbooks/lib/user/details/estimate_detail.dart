import 'dart:io';

//import 'package:quickbooks/Screens/Welcome/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:progress_dialog/progress_dialog.dart';
//import 'package:quickbooks/Screens/admin/all_users.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/config/styles.dart';
import 'package:http/http.dart' as http;
import 'package:quickbooks/user/user_menu/estimates.dart';

import '../../constants.dart';
//import 'package:quickbooks/Screens/admin/add_customer.dart';

class EstimateDetails extends StatefulWidget {
  String estimate_id,est_no, cus_name, terms, date, due_on,discount,shipping_fee,sales_tax,price,mess_to_cus,mess_to_state;
  EstimateDetails(
      {Key key, this.estimate_id,this.est_no, this.cus_name, this.terms, this.date, this.due_on,this.discount,this.shipping_fee,this.price,this.sales_tax,this.mess_to_cus,this.mess_to_state})
      : super(key: key);

  @override
  _EstimateDetails createState() => _EstimateDetails();
}

class _EstimateDetails extends State<EstimateDetails> {
  Future<bool> _onBackPressed() {
    Navigator.pop(context);
  }

  Future<bool> dialog() {
    return showDialog(
        context: context,
        builder: (context) => AlertDialog(
              title: Text("Do you want to delete ${widget.cus_name}'s estimate"),
              actions: [
                FlatButton(
                  child: Text("No"),
                  onPressed: () => Navigator.pop(context, false),
                ),
                FlatButton(
                  child: Text("Yes"),
                  onPressed: () {
                    del_Invoice();
                  },
                ),
              ],
            ));
  }
  
Future del_Invoice() async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    final uri = Uri.parse(base_url + "del_estimate.php?id='${widget.estimate_id}'");
    var request = http.MultipartRequest('POST', uri);
    request.fields['auth_key'] = auth_key;
    var response = await request.send().then((result) async {
      http.Response.fromStream(result).then((response) {
        if (response.body == "deleted") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Estimate deleted successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);

               var route = new MaterialPageRoute(
              builder: (BuildContext context) => new Estimates());
          Navigator.of(context).push(route);
          //
        } else if (response.body == "not deleted") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "estimate is not deleted successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Access forbidden") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Access forbidden",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Connection Error") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Connection Error",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else {
          dialog.hide();
          Fluttertoast.showToast(
              msg: response.body,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      });
    });
  }



  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Palette.primaryColor,
          elevation: 0.0,
          title: Text('Estimate details'),
        ),
        body: CustomScrollView(
          physics: ClampingScrollPhysics(),
          slivers: <Widget>[
            _buildHeader(screenHeight),
            // _buildPreventionTips(screenHeight),
            // _buildYourOwnTest(screenHeight),
          ],
        ),
      ),
    );
  }

  SliverToBoxAdapter _buildHeader(double screenHeight) {
    return SliverToBoxAdapter(
      child: Container(
        padding: const EdgeInsets.all(20.0),
        decoration: BoxDecoration(
          color: Palette.primaryColor,
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(40.0),
            bottomRight: Radius.circular(40.0),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  '${widget.cus_name}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 25.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                // CircleAvatar(
                //           radius: 32,
                //           backgroundImage:
                //               NetworkImage(
                //                 'http://www.pngall.com/wp-content/uploads/5/Profile-Avatar-PNG.png'
                //     ),
                //         ),
                // CountryDropdown(
                //   countries: ['CN', 'FR', 'IN', 'IT', 'UK', 'USA'],
                //   country: _country,
                //   onChanged: (val) => setState(() => _country = val),
                // ),
              ],
            ),
            SizedBox(height: screenHeight * 0.01),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  'estimate no : ${widget.est_no}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                Text(
                  'terms : ${widget.terms}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Date:  ${widget.date}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Due Date:  ${widget.due_on}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Discount:  ${widget.discount}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Shipping fee: Rs  ${widget.shipping_fee}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Sales tax:  ${widget.sales_tax}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Sales tax amount:  ${widget.shipping_fee}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Total price:  ${widget.price}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Message to cutomer:  ${widget.mess_to_cus}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Message to Statement:  ${widget.mess_to_state}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Currency: PKR',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.03),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    FlatButton.icon(
                      padding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 10.0,
                      ),
                      onPressed: () {
                        // var route = new MaterialPageRoute(
                        //     builder: (BuildContext context) => new EditInvoice(
                        //         estiate_id: '${widget.estimate_id}',
                        //         cus_name: '${widget.cus_name}',
                        //         invoice_no: '${widget.invoice_no}',
                        //         date: '${widget.date}',
                        //         due_on: '${widget.due_on}',
                        //         discount: '${widget.discount}',
                        //         shipping_fee: '${widget.shipping_fee}',
                        //         sales_tax: '${widget.sales_tax}',
                        //         price: '${widget.price}',
                        //         mess_to_cus: '${widget.mess_to_cus}',
                        //         mess_to_state: '${widget.mess_to_state}'));
                        //Navigator.of(context).push(route);
                        //     var route=new MaterialPageRoute(
                        // builder:(BuildContext context)=>
                        // new WelcomeScreen());
                        // Navigator.of(context).push(route);
                        //
                      },
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      icon: const Icon(
                        Icons.edit,
                        color: Palette.primaryColor,
                      ),
                      label: Text(
                        'Edit Estimate',
                        style: Styles.buttonTextStyle,
                      ),
                      textColor: Palette.primaryColor,
                    ),
                  ],
                ),
                SizedBox(height: screenHeight * 0.03),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    FlatButton.icon(
                      padding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 10.0,
                      ),
                      onPressed: () {
                        dialog();
                        //     var route=new MaterialPageRoute(
                        // builder:(BuildContext context)=>
                        // new WelcomeScreen());
                        // Navigator.of(context).push(route);
                      },
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      icon: const Icon(
                        Icons.delete,
                        color: Palette.primaryColor,
                      ),
                      label: Text(
                        'Delete Estimate',
                        style: Styles.buttonTextStyle,
                      ),
                      textColor: Palette.primaryColor,
                    ),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  // SliverToBoxAdapter _buildPreventionTips(double screenHeight) {
  //   return SliverToBoxAdapter(
  //     child: Container(
  //       padding: const EdgeInsets.all(20.0),
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         children: <Widget>[
  //           Text(
  //             'Prevention Tips',
  //             style: const TextStyle(
  //               fontSize: 22.0,
  //               fontWeight: FontWeight.w600,
  //             ),
  //           ),
  //           const SizedBox(height: 20.0),
  //           Row(
  //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //             children: prevention
  //                 .map((e) => Column(
  //                       children: <Widget>[
  //                         Image.asset(
  //                           e.keys.first,
  //                           height: screenHeight * 0.12,
  //                         ),
  //                         SizedBox(height: screenHeight * 0.015),
  //                         Text(
  //                           e.values.first,
  //                           style: const TextStyle(
  //                             fontSize: 16.0,
  //                             fontWeight: FontWeight.w500,
  //                           ),
  //                           textAlign: TextAlign.center,
  //                         )
  //                       ],
  //                     ))
  //                 .toList(),
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }

  // SliverToBoxAdapter _buildYourOwnTest(double screenHeight) {
  //   return SliverToBoxAdapter(
  //     child: Container(
  //       margin: const EdgeInsets.symmetric(
  //         vertical: 10.0,
  //         horizontal: 20.0,
  //       ),
  //       padding: const EdgeInsets.all(10.0),
  //       height: screenHeight * 0.15,
  //       decoration: BoxDecoration(
  //         gradient: LinearGradient(
  //           colors: [Color(0xFFAD9FE4), Palette.primaryColor],
  //         ),
  //         borderRadius: BorderRadius.circular(20.0),
  //       ),
  //       child: Row(
  //         mainAxisAlignment: MainAxisAlignment.spaceAround,
  //         children: <Widget>[
  //           Image.asset('assets/images/own_test.png'),
  //           Column(
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             children: <Widget>[
  //               Text(
  //                 'Do your own test!',
  //                 style: const TextStyle(
  //                   color: Colors.white,
  //                   fontSize: 18.0,
  //                   fontWeight: FontWeight.bold,
  //                 ),
  //               ),
  //               SizedBox(height: screenHeight * 0.01),
  //               Text(
  //                 'Follow the instructions\nto do your own test.',
  //                 style: const TextStyle(
  //                   color: Colors.white,
  //                   fontSize: 16.0,
  //                 ),
  //                 maxLines: 2,
  //               ),
  //             ],
  //           )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  //   Size size = MediaQuery.of(context).size;
  //   return Scaffold(
  //     body: Stack(
  //       children: <Widget>[
  //         Container(
  //           height: 50,
  //           decoration: BoxDecoration(
  //             image: DecorationImage(
  //               alignment: Alignment.topLeft,
  //               image: AssetImage('assets/images/signup_top.png'),
  //             ),
  //           ),
  //         ),
  //         SafeArea(
  //           child: Padding(
  //             padding: const EdgeInsets.all(16.0),
  //             child: Column(
  //               children: <Widget>[
  //                 Container(
  //                   height: 60,
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       CircleAvatar(
  //                         radius: 32,
  //                         backgroundImage:
  //                             AssetImage('assets/images/profile.png'),
  //                       ),
  //                       SizedBox(width: 16),
  //                       Column(
  //                         crossAxisAlignment: CrossAxisAlignment.start,
  //                         mainAxisAlignment: MainAxisAlignment.center,
  //                         children: <Widget>[
  //                           Text(
  //                             "${widget.name}",
  //                             style: TextStyle(
  //                                 color: Colors.black,
  //                                 fontSize: 18,
  //                                 fontWeight: FontWeight.w400,
  //                                 fontFamily: 'Montserrat'),
  //                           ),
  //                           Text(
  //                             '${widget.email}',
  //                             style: TextStyle(
  //                                 color: Colors.black,
  //                                 fontSize: 15,
  //                                 fontWeight: FontWeight.w400,
  //                                 fontFamily: 'Montserrat'),
  //                           ),
  //                         ],
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //                 RoundedButton(
  //             text: "All Services",
  //             press: () {
  //               // setState(() {
  //               //   _email = email_controller.text;
  //               //   _password = password_controller.text;
  //               // });
  //               Navigator.push(
  //                 context,
  //                 MaterialPageRoute(
  //                   builder: (context) {
  //                     return UserServicesList();
  //                   },
  //                 ),
  //               );
  //             },
  //           ),
  //                 ],
  //             ),
  //           ),
  //         )
  //       ],
  //     ),
  //   );
}
