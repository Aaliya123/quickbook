import 'dart:io';

//import 'package:quickbooks/Screens/Welcome/welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:progress_dialog/progress_dialog.dart';
//import 'package:quickbooks/Screens/admin/all_users.dart';
import 'package:quickbooks/config/palette.dart';
import 'package:quickbooks/config/styles.dart';
import 'package:http/http.dart' as http;
import 'package:quickbooks/main.dart';
import 'package:quickbooks/user/operations/edit_customer.dart';
import 'package:quickbooks/user/user_menu/customers.dart';

import '../../constants.dart';

//import 'package:quickbooks/Screens/admin/add_customer.dart';

class UserDetails extends StatefulWidget {
  // String id,name,email,profile,mobile;
  // UserDetails({Key key,this.id,this.name,this.email,this.profile,this.mobile}):super(key: key);
  String id;
  String name;
  String company_name;
  String phone;
  String mobile;
  String fax;
  String email;
  String address1;
  final String address2;
  final String address3;
  final String city;
  final String state;
  final String zip;
  final String country;
  // final int code;
  UserDetails({
    this.id,
    this.name,
    this.company_name,
    this.phone,
    this.mobile,
    this.fax,
    this.email,
    this.address1,
    this.address2,
    this.address3,
    this.city,
    this.state,
    this.zip,
    this.country,
  });
  // UserDetails(
  //     this.id,
  //     this.name,

  // this.code
  //);

  @override
  _UserDetails createState() => _UserDetails();
}

class _UserDetails extends State<UserDetails> {
  Future<bool> _onBackPressed() {
    Navigator.pop(context);
  }

  Future<bool> dialog() {
    return showDialog(
        context: context,
        builder: (context) => AlertDialog(
              title: Text("Do you want to delete ${widget.name}"),
              actions: [
                FlatButton(
                  child: Text("No"),
                  onPressed: () => Navigator.pop(context, false),
                ),
                FlatButton(
                  child: Text("Yes"),
                  onPressed: () {
                    del_Customer();
                    
                  },
                ),
              ],
            ));
  }

Future del_Customer() async {
    ProgressDialog dialog = new ProgressDialog(context);
    dialog.style(message: 'Please wait...');
    await dialog.show();
    final uri = Uri.parse(base_url + "del_customer.php?id='${widget.id}'");
    var request = http.MultipartRequest('POST', uri);
    request.fields['auth_key'] = auth_key;
    var response = await request.send().then((result) async {
      http.Response.fromStream(result).then((response) {
        if (response.body == "deleted") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Customer deleted successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);

               var route = new MaterialPageRoute(
              builder: (BuildContext context) => new Customer());
          Navigator.of(context).push(route);
          //
        } else if (response.body == "not deleted") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Customer is not deleted successfully",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Access forbidden") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Access forbidden",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else if (response.body == "Connection Error") {
          dialog.hide();
          Fluttertoast.showToast(
              msg: "Connection Error",
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        } else {
          dialog.hide();
          Fluttertoast.showToast(
              msg: response.body,
              toastLength: Toast.LENGTH_SHORT,
              gravity: ToastGravity.CENTER,
              backgroundColor: Colors.red,
              textColor: Colors.white,
              fontSize: 16.0);
        }
      });
    });
  }


  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;
    return WillPopScope(
      onWillPop: _onBackPressed,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Palette.primaryColor,
          elevation: 0.0,
          title: Text('Dashboard'),
        ),
        body: CustomScrollView(
          physics: ClampingScrollPhysics(),
          slivers: <Widget>[
            _buildHeader(screenHeight),
            // _buildPreventionTips(screenHeight),
            // _buildYourOwnTest(screenHeight),
          ],
        ),
      ),
    );
  }

  SliverToBoxAdapter _buildHeader(double screenHeight) {
    return SliverToBoxAdapter(
      child: Container(
        padding: const EdgeInsets.all(20.0),
        decoration: BoxDecoration(
          color: Palette.primaryColor,
          borderRadius: BorderRadius.only(
            bottomLeft: Radius.circular(40.0),
            bottomRight: Radius.circular(40.0),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(
                  '${widget.name}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 25.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                // CircleAvatar(
                //           radius: 32,
                //           backgroundImage:
                //               NetworkImage(
                //                 'http://www.pngall.com/wp-content/uploads/5/Profile-Avatar-PNG.png'
                //     ),
                //         ),
                // CountryDropdown(
                //   countries: ['CN', 'FR', 'IN', 'IT', 'UK', 'USA'],
                //   country: _country,
                //   onChanged: (val) => setState(() => _country = val),
                // ),
              ],
            ),
            SizedBox(height: screenHeight * 0.01),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(
                  '${widget.email}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22.0,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),

                // Text(
                //   '${widget.id}',
                //   style: const TextStyle(
                //     color: Colors.white70,
                //     fontSize: 15.0,
                //   ),
                // ),
                Text(
                  'Company: ${widget.company_name}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Phone: ${widget.phone}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Mobile: ${widget.mobile}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Fax: ${widget.fax}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Address: ${widget.address1} ${widget.address2} ${widget.address3}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'City: ${widget.city}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'State: ${widget.state}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'ZIP: ${widget.zip}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Country: ${widget.country}',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.01),
                Text(
                  'Currency: PKR',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20.0,
                  ),
                ),
                SizedBox(height: screenHeight * 0.03),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    FlatButton.icon(
                      padding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 10.0,
                      ),
                      onPressed: () {
                        var route = new MaterialPageRoute(
                            builder: (BuildContext context) => new EditCustomer(
                                id: '${widget.id}',
                                name: '${widget.name}',
                                company_name: '${widget.company_name}',
                                phone: '${widget.phone}',
                                mobile: '${widget.mobile}',
                                fax: '${widget.fax}',
                                email: '${widget.email}',
                                address1: '${widget.address1}',
                                address2: '${widget.address2}',
                                address3: '${widget.address3}',
                                city: '${widget.city}',
                                state: '${widget.state}',
                                zip: '${widget.zip}',
                                country: '${widget.country}'));
                        Navigator.of(context).push(route);
                        //     var route=new MaterialPageRoute(
                        // builder:(BuildContext context)=>
                        // new WelcomeScreen());
                        // Navigator.of(context).push(route);
                        //
                      },
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      icon: const Icon(
                        Icons.edit,
                        color: Palette.primaryColor,
                      ),
                      label: Text(
                        'Edit Customer',
                        style: Styles.buttonTextStyle,
                      ),
                      textColor: Palette.primaryColor,
                    ),
                  ],
                ),
                SizedBox(height: screenHeight * 0.03),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    FlatButton.icon(
                      padding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 10.0,
                      ),
                      onPressed: () {
                        dialog();
                        //     var route=new MaterialPageRoute(
                        // builder:(BuildContext context)=>
                        // new WelcomeScreen());
                        // Navigator.of(context).push(route);
                      },
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30.0),
                      ),
                      icon: const Icon(
                        Icons.delete,
                        color: Palette.primaryColor,
                      ),
                      label: Text(
                        'Delete Customer',
                        style: Styles.buttonTextStyle,
                      ),
                      textColor: Palette.primaryColor,
                    ),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

  // SliverToBoxAdapter _buildPreventionTips(double screenHeight) {
  //   return SliverToBoxAdapter(
  //     child: Container(
  //       padding: const EdgeInsets.all(20.0),
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         children: <Widget>[
  //           Text(
  //             'Prevention Tips',
  //             style: const TextStyle(
  //               fontSize: 22.0,
  //               fontWeight: FontWeight.w600,
  //             ),
  //           ),
  //           const SizedBox(height: 20.0),
  //           Row(
  //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //             children: prevention
  //                 .map((e) => Column(
  //                       children: <Widget>[
  //                         Image.asset(
  //                           e.keys.first,
  //                           height: screenHeight * 0.12,
  //                         ),
  //                         SizedBox(height: screenHeight * 0.015),
  //                         Text(
  //                           e.values.first,
  //                           style: const TextStyle(
  //                             fontSize: 16.0,
  //                             fontWeight: FontWeight.w500,
  //                           ),
  //                           textAlign: TextAlign.center,
  //                         )
  //                       ],
  //                     ))
  //                 .toList(),
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }

  // SliverToBoxAdapter _buildYourOwnTest(double screenHeight) {
  //   return SliverToBoxAdapter(
  //     child: Container(
  //       margin: const EdgeInsets.symmetric(
  //         vertical: 10.0,
  //         horizontal: 20.0,
  //       ),
  //       padding: const EdgeInsets.all(10.0),
  //       height: screenHeight * 0.15,
  //       decoration: BoxDecoration(
  //         gradient: LinearGradient(
  //           colors: [Color(0xFFAD9FE4), Palette.primaryColor],
  //         ),
  //         borderRadius: BorderRadius.circular(20.0),
  //       ),
  //       child: Row(
  //         mainAxisAlignment: MainAxisAlignment.spaceAround,
  //         children: <Widget>[
  //           Image.asset('assets/images/own_test.png'),
  //           Column(
  //             mainAxisAlignment: MainAxisAlignment.center,
  //             crossAxisAlignment: CrossAxisAlignment.start,
  //             children: <Widget>[
  //               Text(
  //                 'Do your own test!',
  //                 style: const TextStyle(
  //                   color: Colors.white,
  //                   fontSize: 18.0,
  //                   fontWeight: FontWeight.bold,
  //                 ),
  //               ),
  //               SizedBox(height: screenHeight * 0.01),
  //               Text(
  //                 'Follow the instructions\nto do your own test.',
  //                 style: const TextStyle(
  //                   color: Colors.white,
  //                   fontSize: 16.0,
  //                 ),
  //                 maxLines: 2,
  //               ),
  //             ],
  //           )
  //         ],
  //       ),
  //     ),
  //   );
  // }

  //   Size size = MediaQuery.of(context).size;
  //   return Scaffold(
  //     body: Stack(
  //       children: <Widget>[
  //         Container(
  //           height: 50,
  //           decoration: BoxDecoration(
  //             image: DecorationImage(
  //               alignment: Alignment.topLeft,
  //               image: AssetImage('assets/images/signup_top.png'),
  //             ),
  //           ),
  //         ),
  //         SafeArea(
  //           child: Padding(
  //             padding: const EdgeInsets.all(16.0),
  //             child: Column(
  //               children: <Widget>[
  //                 Container(
  //                   height: 60,
  //                   child: Row(
  //                     crossAxisAlignment: CrossAxisAlignment.start,
  //                     children: <Widget>[
  //                       CircleAvatar(
  //                         radius: 32,
  //                         backgroundImage:
  //                             AssetImage('assets/images/profile.png'),
  //                       ),
  //                       SizedBox(width: 16),
  //                       Column(
  //                         crossAxisAlignment: CrossAxisAlignment.start,
  //                         mainAxisAlignment: MainAxisAlignment.center,
  //                         children: <Widget>[
  //                           Text(
  //                             "${widget.name}",
  //                             style: TextStyle(
  //                                 color: Colors.black,
  //                                 fontSize: 18,
  //                                 fontWeight: FontWeight.w400,
  //                                 fontFamily: 'Montserrat'),
  //                           ),
  //                           Text(
  //                             '${widget.email}',
  //                             style: TextStyle(
  //                                 color: Colors.black,
  //                                 fontSize: 15,
  //                                 fontWeight: FontWeight.w400,
  //                                 fontFamily: 'Montserrat'),
  //                           ),
  //                         ],
  //                       ),
  //                     ],
  //                   ),
  //                 ),
  //                 RoundedButton(
  //             text: "All Services",
  //             press: () {
  //               // setState(() {
  //               //   _email = email_controller.text;
  //               //   _password = password_controller.text;
  //               // });
  //               Navigator.push(
  //                 context,
  //                 MaterialPageRoute(
  //                   builder: (context) {
  //                     return UserServicesList();
  //                   },
  //                 ),
  //               );
  //             },
  //           ),
  //                 ],
  //             ),
  //           ),
  //         )
  //       ],
  //     ),
  //   );
}
