import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF53B700);
const kPrimaryLightColor = Color(0xFFF1E6FF);
// const base_url = "https://bcesystem.com/";
//const base_url="http://192.168.43.42/quickbooks/quickbooks/database/data.json";
const base_url="http://192.168.0.101/quickbooks/quickbooks/database/";
const auth_key = "123456789abvfggvsgretsig4894318";
  